# Structure Template

Copy this skeleton for every Intent-to-Model Mapping. Fill each `<...>` with product-specific content or an `[ASSUMPTION TO VALIDATE: <question>]` flag. Do not drop, reorder, or rename the seven parts. Do not alter the six fixed layers in the diagram — the whole genre depends on readers finding the same six layers in the same place every time.

---

## Part 0 — Header metadata

```
| Field           | Value |
|-----------------|-------|
| Document        | <Product> — Query / Intent-to-Model Mapping |
| Parent doc      | <link to the product/PRD this implements> |
| Companion docs  | <response-policy spec, eval plan, taxonomy> |
| Purpose         | Contract between design & engineering: maps any user utterance to signal → intent → confidence → response move, auditably. |
| Version         | v0.1 — <date> — <author> |
```

---

## Part 1 — The pipeline in one picture

Copy this diagram verbatim; the six layers are fixed. Add product-specific model names in the brackets.

```
USER UTTERANCE  (text / voice / image)
        │
        ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 1 · SIGNAL EXTRACTION                                   │
│   NER · domain classifiers · [vision encoder] · [audio ASR]  │
│   → what the user SAID                                        │
└─────────────────────────────────────────────────────────────┘
        │  raw signals
        ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 2 · CONTEXT ENRICHMENT                                  │
│   user profile · world/geo/catalog services · session memory │
│   → what we KNOW about them & the world                      │
└─────────────────────────────────────────────────────────────┘
        │  enriched signals
        ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 3 · INTENT & ROUTING                                    │
│   intent classifier · signal-stacking scorer ·               │
│   knowledge-gap estimator · stakes/reversibility estimator ·  │
│   confidence calibration                                      │
│   → intent + calibrated confidence + stakes class            │
└─────────────────────────────────────────────────────────────┘
        │  intent, score, stakes
        ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 4 · RESPONSE POLICY   ◀── THE DECISION SPINE           │
│   selects the response move / blend:                         │
│   < the product's confirmed response-move spine >            │
└─────────────────────────────────────────────────────────────┘
        │  chosen move(s)
        ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 5 · EXECUTION                                          │
│   < services that fulfill the intent >                       │
└─────────────────────────────────────────────────────────────┘
        │  outcome + user reaction
        ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 6 · FEEDBACK                                           │
│   session re-ranker · profile / adaptation learner           │
└─────────────────────────────────────────────────────────────┘
        └────────────► feeds Layer 2 next turn
```

> **Design rationale.** Extraction (Layer 1) is *what the user said*; enrichment (Layer 2) is *what we know about them and the world*. They are separated on purpose. At incident time this separation is the difference between "the model misheard the user" and "the model misjudged our data about the user" — two different bugs, two different owners, two different fixes. Fusing them would save a box in the diagram and cost you every future debugging session.

---

## Part 2 — Signal → Model responsibility matrix

One row per signal.

```
| Signal | Detected by | Input | Output | Consumed by |
|--------|-------------|-------|--------|-------------|
| <signal> | <model/service> | <raw input> | <typed output> | <downstream layer/model> |
```

Embed **semantic bridging** here where relevant: the Output column should carry the typed, validated form of the user's vocabulary (e.g. `"high cost" → amount >= $5,000`) or an explicit "unbound — needs default" note.

> **Design rationale.** <Why these signals and not others; which are cheap/reliable vs. expensive/noisy; where a single model owns multiple signals and why that coupling is acceptable or a known risk.>

---

## Part 3 — Intent classes → routing → response

Cover the full space. Include the "no special behavior" row and the "ambiguous → disambiguate first" row.

```
| Intent class | Defining signals | Dominant deficit | Route | Default response blend |
|--------------|------------------|------------------|-------|------------------------|
| <class>            | <signals that define it> | <what the user lacks: info / trust / access / clarity> | <which services> | <move(s) from the spine> |
| no special behavior| <clear, low-stakes signals> | none | <direct execution> | <default move> |
| ambiguous          | <conflicting/sparse signals, collision hit> | clarity | <disambiguation> | Ask |
```

---

## Part 4 — Confidence thresholds → response selection

Decision table keyed on calibrated score × stakes × reversibility × profile depth.

```
| Calibrated score | Stakes | Reversibility | Profile depth | → Response move |
|------------------|--------|---------------|---------------|-----------------|
| <band> | <low/med/high> | <reversible/irreversible> | <thin/rich> | <move> |
| any    | any    | IRREVERSIBLE  | any           | CONFIRM (always) |
```

The `irreversible ⇒ confirm` row is mandatory and is a safety invariant, not a tunable.

> **Calibration note.** Thresholds are **per-category and per-locale/segment, never global** — a 0.7 that's safe for browsing is reckless for payments, and a threshold tuned on one market misfires in another. Owned by <data science team>. Reviewed against <named guardrail metric(s)> on <cadence>.

---

## Part 5 — Worked examples

5–6 examples (A–F) spanning: knowledge-led, trust/stakes-led, friction/logistics-led, exploratory/low-clarity, clear-transactional, adaptation/repeat-user.

```
### Example <X> — <one-line label of the intent type>
> "<the actual user utterance, messy and realistic>"

| Step | Result |
|------|--------|
| L1 Signal extraction | <signals pulled> |
| L2 Context enrichment| <what profile/world/session added> |
| L3 Intent & routing  | <intent class, calibrated score, stakes/reversibility> |
| L4 Response policy    | <the resolved move or blend — the payoff line> |
| L5 Execution          | <what actually happens> |
```

Each example must end at a concrete Response move. If it ends in an abstraction, it isn't finished.

---

## Part 6 — Model ownership & eval

```
| Layer / model | Owner | Primary eval metric (with target) |
|---------------|-------|-----------------------------------|
| <model> | <team> | <metric> ≥/≤ <number> |
```

> **Debuggability rationale.** Every model above maps to a metric with a target number. When the agent misbehaves, the team argues about a **number that moved**, not a **vibe about the AI**. That is the whole point of the document.

---

## Part 7 — Footer

```
Companion documents: <links>
Version: v0.1 — <date> — <author>
```
