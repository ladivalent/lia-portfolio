# House Style

The rules that make an Intent-to-Model Mapping read like the genre and not like a generic design doc. Check the finished deliverable against every item here before delivering.

## The spine is the heart

Layer 4 (Response Policy) selects from a small, named set of **response moves**. This set — the *spine* — is the load-bearing decision of the entire document. A team may already have its own agent-role framework, but any such set is a property of a specific product, not a template default.

- Never hardcode a spine. Elicit the product's real moves, or propose a candidate set and get explicit confirmation.
- Every table in the document must resolve *into* the confirmed spine. The intent→routing table's last column, the confidence decision table's output, and every worked example's payoff line all name a move from the same spine. If they don't line up, the doc is internally inconsistent.
- A good spine is small (usually 3–5 moves), mutually distinguishable, and covers the space from "give information" to "take action" with the cautious middle-ground moves in between.

## Auditability is the point, everywhere

- Every *behavior* the agent takes traces to a specific layer and model.
- Every *model* traces to a named eval metric with a target number.
- If a claim in the doc can't be traced to a layer/model, or a model can't be traced to a metric, the doc has a hole. Fill it or flag it.

## Confidence and stakes

- Express confidence as **calibrated 0–1 scores**, not raw logits or hand-wavy "high/medium/low" alone. If you use bands, define them.
- Pair every score with a **stakes class** (money / safety / fraud / wasted trip) and a **reversibility class** (reversible / irreversible).
- **Irreversible actions always confirm**, regardless of score. This is a safety invariant. It gets its own explicit row in the Part 4 table.

## Calibration is contextual, never global

Whenever you state a threshold, state the axes it varies on. Thresholds are:
- **per-category** (browsing ≠ payments),
- **per-locale/segment** (a threshold tuned in one market misfires in another),
- **owned by data science** (not design, not eng),
- **reviewed against named guardrail metrics** on a stated cadence.

A global threshold is a bug. Saying "we set confidence to 0.7" without the axes is the tell of a doc that hasn't thought about calibration.

## Design-rationale blockquotes

After the diagram (Part 1) and the key matrices (Parts 2 and 6), add a `>` blockquote in a principal designer's voice explaining the **why** — the tradeoff, the thing that would break if you did it the obvious way, the reason the structure earns its complexity. These are not summaries; they are arguments. A good rationale blockquote makes a reader who wanted to simplify the design understand why they shouldn't.

## Worked examples are production-plausible

- Use real, messy utterances — the way people actually type and talk, including voice and image queries.
- Walk the full pipeline and land on a concrete response move.
- Never "data goes here," never "example TBD." If you don't have a real query, use an `[ASSUMPTION TO VALIDATE]` flag with the question that would get you one.

## Prose is fierce and concrete

- No corporate filler: "improve the user experience," "leverage synergies," "delight users," "seamless." Cut these on sight.
- Test: if a sentence would survive being pasted into *any other product's* doc unchanged, it's too generic. Make it specific to this product.
- Prefer the concrete number, the named model, the actual failure mode over the abstraction.

## When input is thin

Never invent filler to fill a section. Insert `[ASSUMPTION TO VALIDATE: <the exact question that resolves it>]` — a real question the user can answer, not a vague "TBD." When a schema is genuinely ambiguous, present two modeling paths with their performance/UX pros and cons rather than silently picking one.

## Voice checklist (fast pass)

- [ ] Spine confirmed with the user, not borrowed.
- [ ] Every table resolves into the spine.
- [ ] `irreversible ⇒ confirm` row present.
- [ ] Calibration note names the axes + owner + guardrail metric.
- [ ] Rationale blockquotes are arguments, not summaries.
- [ ] Worked examples end in concrete moves.
- [ ] No corporate filler.
- [ ] Every model has a target number; every behavior traces to a model.
- [ ] Gaps carry real `[ASSUMPTION TO VALIDATE]` questions, not placeholders.
