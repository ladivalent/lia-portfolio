---
name: intent-model-mapping
description: Use when the user wants a Query/Intent-to-Model Mapping, an intent-routing blueprint, a signal-to-model responsibility matrix, a confidence/threshold decision table, or a design↔engineering contract for an agentic search, commerce, or assistant product. Trigger whenever someone needs to map natural-language, voice, or image user queries to which model extracts which signal and which response the product should make — even when they call it a "routing spec," "intent taxonomy," "signal matrix," "decision spine," or ask "how should the agent decide what to do?" Also use for auditability blueprints that trace every agent behavior to a layer/model and every model to an eval metric.
---

# Intent-to-Model Mapping

## What this produces

A **Query / Intent-to-Model Mapping** is the contract between design and engineering for an agentic search/commerce/assistant product. For any user utterance it answers three questions: which model extracts which signal, how those signals stack into an intent plus a confidence score, and which *response move* the product should make.

The entire reason the genre exists is **auditability**. When the agent does the wrong thing, the team must be able to point at the exact layer and model that failed instead of shrugging at "the AI." So every behavior in the document traces to a layer/model, and every model traces to a named eval metric. If a section can't be traced that way, it isn't done.

Keep that north star in mind the whole time you build one: *someone will read this doc at 2am during an incident and need to find the culprit layer in under a minute.*

## Before you write anything: gather inputs

Read `references/structure-template.md` for the exact skeleton and `references/house-style.md` for voice and rules. Then collect the six inputs below. If the user gave you a thin brief, do **one** of two things for each gap — never invent filler:

- Ask a tight, batched round of questions to fill the most load-bearing gaps, **or**
- Proceed and mark each gap inline with an explicit `[ASSUMPTION TO VALIDATE: <the exact question that resolves it>]` flag.

The inputs:

1. **Product / domain and its core job** — what the thing is for, in one concrete sentence.
2. **The response-move spine** — the set of moves Layer 4 chooses among. *This is the single most load-bearing decision in the document* (see below). Elicit it or propose a candidate set and get explicit confirmation.
3. **Category / tier taxonomy and the stakes model** — the axes that make one query riskier than another: money, safety, fraud, wasted trip, reversibility.
4. **The domain signals worth extracting** — the entities and attributes the product actually cares about.
5. **Representative queries** — real user utterances to turn into worked examples. Ask for messy ones, not clean ones.
6. **Guardrail metrics the team already tracks** — so the eval table cites metrics that exist, not aspirational ones.

### The response-move spine is load-bearing — never borrow it silently

Layer 4 (Response Policy) is the heart of the whole document, and it selects from a small set of *response moves*. Any particular set, including your team's agent-role framework if it has one, is a property of a specific product, not a universal. Do **not** hardcode it.

Instead: ask the user for their product's actual response moves, or propose a candidate spine and get confirmation before building on it. Everything downstream — the intent→routing table, the confidence decision table, the worked examples — resolves *into* these moves, so getting the spine wrong quietly corrupts every section that follows. Confirm it first.

## Build the six-layer structure

Reproduce the parts in `references/structure-template.md` **in order**. The seven parts:

**0. Header metadata table** — Document, Parent/Companion docs, Purpose, Version.

**1. The pipeline in one picture** — the canonical ASCII six-layer diagram (copy it from the template; the six layers are fixed), followed by a design-rationale blockquote. The layers are always:

1. **Signal Extraction** — NER + domain classifiers + any vision/audio encoders. *What the user said.*
2. **Context Enrichment** — user profile, world/geo/catalog services, session memory. *What we know about them and the world.*
3. **Intent & Routing** — intent classifier, signal-stacking scorer, knowledge-gap estimator, stakes/reversibility estimator, confidence calibration.
4. **Response Policy** — the **decision spine**; selects the response move or a blend of moves.
5. **Execution** — the services that actually fulfill the intent.
6. **Feedback** — session re-ranker + profile/adaptation learner.

The rationale blockquote after the diagram must make the auditability argument: extraction is kept separate from enrichment so that, at incident time, you can tell "the model misheard the user" apart from "the model misjudged what we know about the user." Separation *is* the debuggability.

**2. Signal → Model responsibility matrix** — one row per signal: `| Signal | Detected by | Input | Output | Consumed by |`. Close with a design-rationale blockquote.

**3. Intent classes → routing → response** — `| Intent class | Defining signals | Dominant deficit | Route | Default response blend |`. Cover the *whole* space, and explicitly include two classes people forget: the **"no special behavior"** class (the agent should just do the obvious thing) and the **"ambiguous → disambiguate first"** class. A taxonomy without those two is incomplete.

**4. Confidence thresholds → response selection** — a decision table keyed on calibrated scores × stakes × reversibility × profile depth → the chosen response move. **Always include an explicit row for `irreversible action ⇒ confirm`** — this is a safety invariant, not a preference. Close with a calibration note (see house style): thresholds are per-category and per-locale/segment, never global, owned by data science, reviewed against named guardrail metrics.

**5. Worked examples** — 5–6 concrete queries (A–F) spanning the intent space:
- knowledge-led (user lacks information)
- trust/stakes-led (money, safety, or fraud on the line)
- friction/logistics-led (the blocker is operational, not informational)
- exploratory / low-clarity (the user barely knows what they want)
- clear-transactional (the user knows exactly what they want)
- adaptation / repeat-user (session memory or profile changes the move)

Each example is a query line followed by a `| Step | Result |` table that walks the pipeline layer by layer and *ends in the resolved Response move*. These must be specific and production-plausible — never "data goes here."

**6. Model ownership & eval** — `| Layer / model | Owner | Primary eval metric |` with concrete target numbers. Close with the debuggability rationale: every model maps to a metric, so when something breaks the team argues about a **number**, not a **vibe**.

**7. Footer** — companion documents + version.

## The fine-grained parsing that lives inside Layers 1–3

These three analyses are refinements *inside* the six-layer structure — they sharpen it, they don't replace it.

- **Speech-act / intent parsing** (Layer 1→3): separate the implicit goal from the explicit request. Pull out the action-verbs and the entity-nouns. "Can you not charge me twice" is a request-to-verify wearing a request-to-act's clothes; name that.
- **Semantic bridging** (a refinement of the Signal→Model matrix): map the user's vocabulary to system entities *with data types and validation rules*. E.g. "high costs" → `amount >= $5,000`, **or** a flag that "high" is undefined and needs a settings default. When you write a bridge, either bind the term to a typed rule or flag it as unbound — don't leave it fuzzy.
- **Collision handling** (feeds the disambiguation route): name semantic collisions and specify the fallback. Search "Bill" = a person vs. an invoice → the fallback is a clarifying UI, a default hierarchy, or a disambiguation Ask. Every named collision needs a named resolution.

## Self-check before you deliver

Run one critique pass against the house-style rules in `references/house-style.md`. Concretely, verify:

- Every part 0–7 is present and in order.
- The response-move spine was confirmed with the user (not silently borrowed) and every table resolves into it.
- Layer 4 has an explicit `irreversible ⇒ confirm` row.
- The calibration note states the axes thresholds vary on (category, locale/segment) and names an owner + guardrail metric.
- Every model in part 6 has a target number, and every behavior in the doc traces back to one of those models.
- No generic placeholders survived. Where domain input was thin, an `[ASSUMPTION TO VALIDATE]` flag stands in with a real question.
- The prose is concrete and fierce — no corporate filler ("improve the user experience," "leverage synergies"). If a sentence would survive being pasted into any other product's doc, it's too vague; make it specific to *this* product.

Then tighten and deliver. Ask yourself the incident-at-2am test one more time: could an on-call engineer or a designer misread anything here? If yes, fix it before it ships.

## Output format

Deliver the mapping as a single Markdown document (a `.md` file the user can drop into their doc repo). If the user is clearly working inside a specific tooling context (a Word deliverable for stakeholders, a wiki page), match that — but Markdown is the default because this artifact lives in version control next to the code it governs.
