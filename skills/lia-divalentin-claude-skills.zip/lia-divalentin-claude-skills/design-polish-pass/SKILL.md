---
name: "design-polish-pass"
description: "Final 20% design QA: measured spacing, alignment, and pixel-perfection pass on a finished design or Claude Design artboard. Trigger on: polish pass, pixel-perfect check, QA the spacing, alignment audit, final design QA."
---

# Design Polish Pass

The layout, content, colors, and visual direction are already approved. This skill does NOT redesign, restyle, or rewrite copy. Its only job is to find and fix spacing, alignment, and pixel-level defects that keep a design from looking production-ready.

## Inputs

Before starting, establish from the file (never assume — read it):
- **Surface**: Claude Design artboard, HTML/CSS/React, Figma, or a screenshot. Claude Design now lives inside Claude as the **Design** artifact type, so an artboard is usually a claude.ai artifact link; an older export may still be a `.dc.html` file. Treat both as the same surface.
- **Design system** (if one is attached): Claude Design systems are now artifacts of their own. If the design was built on one, read it and take the spacing scale, radius families, type scale, and icon size from its tokens. Those tokens are the source of truth; the defaults below apply only when no system is attached.
- **Frame**: artboard width/height (phone ≈ 390×844; desktop per file). Nothing may overflow it horizontally.
- **Base spacing unit**: from the design system if attached; otherwise 4px unless the file clearly uses 8px. Preferred steps: 4 / 8 / 12 / 16 / 20 / 24 / 32 / 40.
- **Screen margin**: one value used everywhere. Report the value found.
- **Grid** (if any): columns, gutter, margin.
- **Safe areas** (phone): status bar and home-indicator zones — no content under either.

## How to measure, by surface

- **Design artifact or code**: read the source values, then render it and read the real boxes (element rectangles from a headless browser when the session has one). Source and render must agree; where they differ, the render wins and the difference is a finding.
- **Figma**: read values through the Figma tools after loading the required `figma-use` skill.
- **Screenshot**: measure with image tools, not by sight. Open the file in the sandbox (PIL or OpenCV), crop and zoom to each region, and read edges from pixel coordinates. State the image's pixel size and its device scale (1x / 2x / 3x) first, then report CSS px = image px ÷ scale. Images over 2,576px on the long edge are downscaled before they are viewed, so numbers for those must come from the file itself. If no image tool is available, mark every value from that screenshot as "visual estimate, ±2px".

## Procedure — work in this order, do not skip a step

For each step: report what was measured, what was found, and the exact fix (CSS property + value, or Figma property).

### 1. Edges & margins
- Every section, list, card group, header, and input must share the same left/right margin. Measure each.
- Full-bleed elements (dividers, carousels, sticky bars) reach exactly 0 and 100% — not 1px short.
- Sticky/fixed elements (headers, bottom nav) must not overlap scroll content; scroll-area padding must equal their heights exactly.

### 2. Spacing system
- Audit every margin, padding, and gap. List every value that is not a multiple of the base unit (or not a token of the attached design system) and snap it.
- Repeated elements must be identical: every card, chip, list row, nav item. Measure each instance.
- Padding inside chips, buttons, and inputs is symmetrical left/right. Icon-only buttons are perfectly square.
- Vertical rhythm: gap between sections > gap between items > gap between lines inside an item. Flag inversions.
- Check line-height on all text; unequal leading is the usual cause of a label looking off against an icon.

### 3. Alignment
- Overlay guides and confirm; never eyeball.
- Left edges, right edges, centerlines, and baselines across every group of related elements.
- Icon + text pairs: optically centered, not just mathematically. Check for icons 1px high/low.
- Buttons, inputs, chips in a row: same height, same vertical center.
- Prices, values, or numbers in a row/grid share one baseline.
- Section title left edge = screen margin; trailing link right edge = screen margin; both on one baseline.
- Grid gutters equal; last column ends exactly at the right margin.
- Nav items evenly distributed; active state does not shift position.

### 4. Pixel perfection
- No fractional pixel values (13.5px, 33.33%, half-pixel transforms). Convert to integers or use flex/grid with integer gaps.
- 1px dividers and borders are crisp — not blurred by transforms or sub-pixel positions.
- Border radius consistent per family (all cards same, all chips same, all buttons same). List outliers.
- Icons: same set, same stroke weight, same rendered size. Flag any scaled or visually heavier/lighter.
- Images: same aspect ratio and object-fit within a family; no stretch, letterbox, or 1px gaps at edges.
- Text: exact type-scale sizes, no scale transforms, no orphaned single words on last lines; long text truncates with ellipsis after a fixed line count, never overflows mid-word.
- Tap targets ≥ 44×44 hit area on touch surfaces (padding may supply it).

### 5. States (if present)
- Hover / active / selected / pressed / focus / disabled must not shift layout by even 1px (borders replace borders, not add).

### 6. Final sweep
- Inspect at 200% from top to bottom, edge to edge (crop and zoom the render or screenshot). Report anything even slightly off.
- Squint test: visual weight balanced; the eye moves through the intended hierarchy without a snag.

## Output format

First, a table:

| # | Element / selector | Issue | Current value | Corrected value | Severity (Blocker / Should-fix / Nit) |

Then apply every **Blocker** and **Should-fix** directly to the design. List **Nits** for the user's review and do not apply them until told to.

Where the fixes go:
- **Claude Design artboard (Design artifact)**: read the artifact, edit it in place following the Design type's own instructions, and republish to the same link. Never publish a second copy. If the artifact is view-only, return the table and the exact fixes instead.
- **Older `.dc.html` export**: edit the file in place and return it.
- **Code**: edit the source files.
- **Figma**: use the Figma tools after loading the required `figma-use` skill.
- **Screenshot**: return the table only, with pixel measurements.

## Done means

The pass is finished when the re-run in the last rule below finds no Blocker or Should-fix, or when each one that remains is listed with the reason it was not applied. Say which of the two it was.

## Rules
- Measure from the code and the rendered output. Never estimate. If something cannot be measured, say so.
- Never introduce a new design decision. If a fix would require one, flag it and stop. Snapping a value to an attached design system's token is not a new decision; choosing between two tokens is.
- Report in pixels, not words like "slightly" or "a bit."
- Zero findings is not an acceptable first-pass result. If nothing is found, list exactly what was measured to prove it.
- After applying fixes, run steps 3 and 4 once more — spacing fixes routinely expose new alignment issues.
