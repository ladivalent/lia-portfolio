---
name: design-skill-refresh
description: "Audit lia's design-process skills against the newest Claude model and current prompting/skill-authoring guidance, and propose stronger updated SKILL.md files. Trigger on: refresh my skills, audit my skills, new model update, are my skills current."
---

# Design Skill Refresh

Keeps lia's custom design skills strong as models and tools change. Runs on demand, or from the monthly "Design skills refresh" scheduled task after a new model launches.

## Step 1 — Establish what changed

Search the web (never rely on memory for this) and record:
1. **Newest Claude models**: https://docs.claude.com/en/docs/about-claude/models — model names, release dates, headline capability changes.
2. **Release notes / announcements**: https://www.anthropic.com/news — anything about new models, Claude Design, Skills, Artifacts, or Cowork.
3. **Current prompting guidance**: https://docs.claude.com/en/docs/build-with-claude/prompt-engineering/overview and any model-specific best-practices page for the newest model (e.g. "Claude X prompting best practices"). Note new or changed recommendations: instruction style, use of examples, XML tags, extended thinking, tool-use patterns, things the new model no longer needs to be told.
4. **Skill authoring guidance**: the current docs on Agent Skills / SKILL.md best practices (description length, frontmatter fields, progressive disclosure, trigger phrasing).
5. **Tool changes that touch design work**: Claude Design canvas, Figma MCP tools, Artifacts. Note renamed tools, new capabilities, deprecated steps.

Write a short dated changelog of only the items that could affect how a design skill should be written. If nothing material changed, say so and stop after Step 4 with a "no updates needed" report.

## Step 2 — Inventory lia's design skills

List every custom skill in the session's skill list (the `anthropic-skills:` namespace and any others lia authored) whose purpose is design work. Known ones include:
- design-polish-pass
- design-problem-brief
- journey-audit
- prototype-prompt-generator
- agentic-disambiguation-spec
- intent-model-mapping
- portfolio-presentation
- any newer design skill present

Read each skill's full SKILL.md (its synced copy on disk is read-only reference; find it with Glob on `**/SKILL.md` and match by name).

## Step 3 — Audit each skill

Score each skill on these dimensions, citing the specific line that earns the score:

| Dimension | What to check |
|---|---|
| **Trigger accuracy** | Description names concrete trigger phrases; under ~200 chars; would not fire on unrelated requests. |
| **Model fit** | Instructions written for an older model's weaknesses that the new model no longer has (over-explaining, redundant guardrails, step-by-step hand-holding the model now does natively). Also the reverse: new capabilities the skill should now use (longer context, stronger tool use, vision, extended thinking). |
| **Tool currency** | References to tools, artifact types, or Figma/Claude Design steps that were renamed, replaced, or removed. |
| **Output contract** | Output format is explicit, measurable, and matches where the output goes (canvas, file, chat). |
| **Guardrails** | Rules against scope creep, estimation instead of measurement, and silent design decisions are present and still needed. |
| **Length & structure** | Progressive disclosure: core procedure in SKILL.md, long reference material separated; no dead or duplicated sections. |

Rate each dimension **Strong / Needs update / Missing**.

## Step 4 — Report

Produce a report titled `Design Skill Refresh — <date>` containing:
1. The changelog from Step 1.
2. A table: skill × dimension with ratings.
3. For every skill with at least one **Needs update** or **Missing**: a bulleted list of the exact changes recommended and why, tied to a changelog item.
4. Skills rated Strong across the board, listed as "no change."

In an interactive session, send the report in chat. In a scheduled run, send it with a push notification summary of which skills need attention.

## Step 5 — Propose updated skills

For every skill that needs changes, call `propose_skills` with `kind: "improvement"`, `target: <skill name>`, and the **complete** updated SKILL.md — never a partial edit — keeping everything worth keeping and reusing the existing description unless trigger conditions changed. Batch up to 3 per call. Lia reviews and saves; nothing is changed without her approval.

## Rules
- Never weaken a guardrail just because the new model is smarter; remove a rule only when the changelog shows it is redundant.
- Never rename a skill or change what it is for.
- Every recommended change must cite the changelog item that motivates it. No changes "for style."
- If web search is unavailable, say so and produce the audit from the skills alone, flagging that model/tool currency could not be verified.