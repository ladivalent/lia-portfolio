---
name: journey-audit
description: Use when the user wants an end-to-end user journey audit, a friction or drop-off analysis, a touchpoint-by-touchpoint UX teardown, a current-state→future-state audit of a product flow, or a prioritized UX remediation roadmap. Trigger whenever someone hands over a product flow (steps, screenshots, test transcripts, a Figma walkthrough, a written breakdown) and wants an honest diagnosis of where users struggle or abandon — even when they call it a "UX review," "heuristic evaluation," "flow teardown," "experience map," or "where are we losing people." Also use to benchmark a journey against named competitors or to turn scattered usability findings into an ID'd, severity-ranked audit.
---

# Journey Audit

## What this produces

An End-to-End User Journey Audit is the team's shared, referenceable map of *where an experience breaks*. Its entire value is **honesty enforced by structure**: every touchpoint or stage is scored on the same axes and carries a stable ID, so the team argues about `F3` or `B7` — a specific, located friction — instead of trading vibes about "the UX feeling off."

A strong audit is fierce and concrete. It names real UI components, real microcopy, real competitors. It says "the promo code silently clears when the user goes back a step" and "the full-screen date picker is the #1 mobile sin," not "improve discoverability." If a line would survive being pasted into any other product's audit, it is too vague to earn its place.

Work the procedure below; the two template skeletons and the severity legend it points to live in `references/`.

## Step 1 — Gather inputs

Collect these. Where a piece is missing, do **not** invent a finding — flag it with `[BLIND SPOT: USER TESTING REQUIRED — <the exact behavior to observe>]` so the gap is visible and actionable.

- **The journey / user goal** being audited.
- **The actor(s)** — one primary, or several (seller + buyer, admin + end-user).
- **Channels / platforms** — desktop, mobile web, iOS, Android.
- **The raw current-flow breakdown** — steps, screenshots, or test transcripts. This is the evidence base; without it you are guessing, and guesses get the blind-spot flag.
- **Competitors to benchmark against** — named ones. The benchmark table is worthless with "industry standards"; it needs the real rivals, by name.
- **Any product decision-spine to overlay** (optional) — e.g. your team's agent-role framework (the modes the agent switches between). Only overlay one if the product *actually has* such a framework; otherwise it's noise. See "The optional modality overlay" below.

## Step 2 — Choose Template A or B (the key judgment)

This is the most important decision in the skill. The two shapes are the *same genre*; picking the wrong one makes the audit fight its own content. Read `references/template-a.md` and `references/template-b.md` for the full skeletons.

**Template A — Actor → Phase → Touchpoint matrix.** Use when the journey spans **multiple actors** (seller + buyer) or a system with **many discrete touchpoints** that don't form one emotional arc. Structure: a PART per actor, Phases within each, and a touchpoint table per phase. Every touchpoint gets a stable ID (`S1, S2…` for seller, `B1, B2…` for buyer).

**Template B — Stage-by-stage current → future.** Use when the journey is **one continuous flow for one primary actor** (Discover → … → Close) with a real emotional arc. Structure: one section per stage, each opening with **User goal**, then a current-state-vs-future-state table split by channel, plus blockquote callouts for moments of truth and platform divergence.

**Decision rule:**
- Multiple actors, or a sprawl of discrete touchpoints with no single arc → **A**.
- One actor, one continuous flow with peaks and dips → **B**.
- Both a clear primary flow *and* a secondary actor → **default to B for the primary actor, and add a Template-A matrix for the secondary.**
- Genuinely ambiguous → present A vs. B with a one-line pro/con each and ask. Don't guess, and don't default to whichever you saw last.

## Step 3 — Decompose the journey on consistent per-unit axes

Whichever template, every unit (touchpoint in A, stage in B) is scored on the same axes so the audit stays comparable end to end. At minimum:

- **User action + goal** — what they do, and what they're *actually trying to accomplish* underneath it.
- **User mental / emotional state** — what they're thinking, expecting, and feeling *at this moment*. This is not decoration; the Peak-End Rule means the worst and last moments dominate how the whole journey is remembered, so locating the emotional lows is a design priority.
- **Interaction cost** — the physical + cognitive effort: typing, scanning, decision paralysis, jargon, memory load. Name the load explicitly.
- **System behavior (current state)** — what the product does today, and how well it provides feedback, clarity, and momentum.
- **Pain points / friction** — the specific breakage, tagged with severity (High / Med / Low) and *why it threatens retention*. Ground the diagnosis in a named principle where one applies (see below) — "eight equal filter chips" is Hick's Law, not just "too many options."
- **Recommendation / future state** — the concrete fix, split by channel where behavior diverges.

In Template A these live inside the columns `| # | Touchpoint | Channel | User Action | System Behavior | Pain Points | Audit Notes |`; when the journey is cognition-heavy, add explicit `Mental State` and `Interaction Cost` columns rather than burying them. In Template B they map to the `Reality / Desktop / Mobile / [System-or-agent] role / Emotional arc / Risk` rows.

### Ground friction in named psychology (folded in, not bolted on)

Don't add a "psychology section." Instead, when you diagnose a friction, name the principle that explains it, right there in the Pain Points cell:

- **Hick's Law** — decision time grows with the number/complexity of choices. (Overloaded filter rails, undifferentiated option grids.)
- **Miller's Law** — ~7±2 items in working memory. (Long uncondensed lists, multi-field forms with no chunking.)
- **Peak-End Rule** — the peak and the final moment color the whole memory. (A rough handoff or a confusing last screen poisons an otherwise fine journey.)
- **Jakob's Law** — users expect your product to work like the others they know. (A bespoke size selector where everyone else uses a button grid.)
- **Nielsen's heuristics** — especially visibility of system status ("is it still available?"), error prevention, and consistency.

Naming the principle turns "this feels clunky" into a diagnosis a designer can act on and defend.

## Step 4 — Cross-cutting synthesis

After the per-unit decomposition, pull back and synthesize. Include the subsections that actually apply — skip the ones that don't rather than padding:

- **Recurring themes / systemic gaps** — the frictions that showed up again and again.
- **Competitor benchmark** — a table using ✅ / ❌ against **named** competitors, one row per capability. This is where you prove the gap is real and not aspirational.
- **Internationalization** — if the journey crosses locales (size systems, currency, date/weekend conventions).
- **Accessibility** — WCAG-grounded, if relevant (ARIA labels, contrast on disabled states, image-only content).
- **Emotional-journey arc** — an ASCII arc across the stages marking peaks and dips, so the two moments that matter most are visible at a glance.
- **Moments of truth** — the make-or-break points where trust is won or lost, each as a blockquote callout.
- **Cross-platform continuity requirements** — if multi-channel: thread persistence, no re-asking, notification routing.

## Step 5 — Prioritized findings + the thesis

Close with a severity-tagged findings table. Every finding gets an ID (`F1, F2…`) so it's citable in standups forever. Tag priority with color dots and pair with Effort × Impact (or Stage × Remedy):

`🔴 P0 (Critical) · 🟠 P1 (High) · 🟡 P2 (Medium) · 🟢 P3 (Future)`

See `references/severity-legend.md` for the full legend and scales.

Then lay a **roadmap lens** over that same table — three tiers, not a separate list:
- **Quick wins** — low effort, high impact (often copy or field-default changes).
- **Strategic overhauls** — structural design/dev work.
- **Copy & clarity fixes** — microcopy, labels, empty states.

End with a one-paragraph **thesis blockquote** in a principal designer's voice: which 2–3 findings are make-or-break, and why fixing them changes the product's competitive position. A strong thesis argues, for example, that fixing three specific frictions makes the product structurally better than its main rival, because the things the rival can't do become the default rather than the exception. A thesis is an argument about leverage, not a summary.

## The optional modality overlay

If the product has an agent or a decision framework (for example, an "agent role" row on every stage naming which of your team's agent-role modes applies), weave it into the per-unit axes so each unit shows what the agent should do there. **Only include this when the product genuinely has such a spine.** Bolting an agent-role overlay onto a product with no agent is exactly the kind of noise this audit is supposed to cut.

## Step 6 — Self-check before delivering

One critique pass against the house-style rules:

- Right template chosen for the actor-count and flow-continuity — not defaulted.
- Every unit and every finding carries a stable, referenceable ID.
- Every pain point names severity and the retention-why; psychology principles cited where they apply.
- The competitor benchmark names real rivals with ✅/❌, not "industry standards."
- Blockquote callouts (moments of truth, divergence, thesis) are arguments in a designer's voice, not summaries.
- Missing evidence is flagged `[BLIND SPOT: USER TESTING REQUIRED]` with a specific behavior to observe — never papered over with a fabricated finding.
- No platitudes. Every recommendation names a component, a microcopy string, or a structural change. Search the draft for "improve the user experience," "make it cleaner," "seamless," "delight" and kill them.

Ask the honesty test one last time: does the audit say plainly where the journey breaks? If it's being polite instead of honest, it has failed at its one job. Tighten, then deliver.

## Output format

Deliver as a single Markdown document the team can drop into their doc repo or wiki. Match the templates' density: tables where tables belong, blockquotes for the "why," IDs everywhere.
