# Template A — Actor → Phase → Touchpoint Matrix

Use when the journey spans **multiple actors** (seller + buyer, admin + end-user) or a system with **many discrete touchpoints** that don't resolve into one emotional arc. Typical shape: two actors, a handful of phases each, touchpoint tables throughout.

Copy this skeleton. Keep the parts and their order. Give every touchpoint a stable ID.

---

```
# <Product> — <Journey> Audit
## End-to-End User Journey: <domain>

**Scope:** <what's in / out of scope>
**Channels:** <Desktop Web, Mobile Web, iOS App, Android App>
**Audit Date:** <month year>
**Version:** <n>

---

## Overview

<One short paragraph: what this maps, and the exact axes each touchpoint is
evaluated on — user action, system behavior, pain points, recommendation — so the
reader knows the lens before the tables start.>

---

## PART 1: <PRIMARY ACTOR> JOURNEY

### Phase 1.1 — <phase name>

| # | Touchpoint | Channel | User Action | System Behavior | Pain Points | Audit Notes |
|---|-----------|---------|-------------|-----------------|-------------|-------------|
| S1 | <touchpoint> | <All / Desktop / iOS…> | <what they do + underlying goal> | <what the system does today> | <specific breakage — severity + retention-why + psychology principle> | <the concrete fix / future state> |
| S2 | … | | | | | |

### Phase 1.2 — <phase name>
| # | Touchpoint | Channel | User Action | System Behavior | Pain Points | Audit Notes |
|---|-----------|---------|-------------|-----------------|-------------|-------------|
| S4 | … | | | | | |

<...more phases...>

---

## PART 2: <SECONDARY ACTOR> JOURNEY

### Phase 2.1 — <phase name>
| # | Touchpoint | Channel | User Action | System Behavior | Pain Points | Audit Notes |
|---|-----------|---------|-------------|-----------------|-------------|-------------|
| B1 | … | | | | | |

<...more phases...>

---

## PART 3: CROSS-CUTTING THEMES & GAPS

### 3.1 <Systemic theme>
| Theme | Current State | Impact | Recommendation |
|-------|--------------|--------|----------------|
| <theme> | <today> | <consequence> | <fix> |

### 3.2 <Capability> — Competitor Benchmark
| Feature | <Product> Today | Industry Benchmark | Gap |
|---------|-----------------|--------------------|-----|
| <feature> | ❌ Not available | ✅ <Named competitor>, <Named competitor> | <Critical / High / Medium> |

### 3.3 Internationalization   <!-- include only if relevant -->
| Region | Issue | Recommendation |
|--------|-------|----------------|

### 3.4 Accessibility   <!-- include only if relevant; WCAG-grounded -->
| Issue | Impact | Recommendation |
|-------|--------|----------------|

---

## PART 4: PRIORITY RECOMMENDATIONS SUMMARY

| Priority | Recommendation | Effort | Impact |
|----------|---------------|--------|--------|
| 🔴 P0 | <fix> | <Low/Med/High> | <High/Very High> |
| 🟠 P1 | … | | |
| 🟡 P2 | … | | |
| 🟢 P3 | … (future) | | |

> **Thesis.** <Which 2–3 findings are make-or-break, and why fixing them
> repositions the product against its named competitors. An argument about
> leverage, not a summary.>

---

*Document Owner: <team>*
*Last Updated: <date>*
*Version: <n>*
```

---

### Notes on Template A

- **Stable IDs are non-negotiable.** `S1…Sn` for the first actor, `B1…Bn` for the second. These IDs are how the finding table and every future standup will reference a touchpoint.
- **The touchpoint columns are the recognizable shape** — keep them. When a journey is cognition-heavy (lots of decision paralysis, jargon, memory load), add explicit `Mental State` and `Interaction Cost` columns rather than cramming them into Pain Points.
- **Pain Points is where the honesty lives.** Tag severity, say why it threatens retention, and name the psychology principle when one applies.
- **The competitor benchmark uses ✅ / ❌ and NAMED rivals.** "Industry standard" is banned; write the actual competitors' names.
