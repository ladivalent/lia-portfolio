# Template B — Stage-by-Stage Current → Future

Use when the journey is **one continuous flow for one primary actor** (Discover → … → Close) with a real emotional arc — peaks and dips the design has to manage. Typical shape: one primary actor, a run of stages, current-state friction vs. future-state experience, split by platform.

Copy this skeleton. Keep the parts and their order. Every stage opens with the user's goal.

---

```
# <Product> — <Journey> Audit
## <Channels> · Current-State Friction and Future-State Experience

| Field | Detail |
|---|---|
| Document | <Journey> Audit (<channels>) |
| Companion to | <parent brief, if any> |
| Scope | <N stages, first → last>; <platforms>; audited for friction, divergence, moments of truth |
| Version | <n> |

---

## 0. How to read this audit

<One block naming the three axes each stage is scored on — what the user is trying
to do, what the experience does today (current-state friction), and what the
redesigned experience should do, split by channel. State the lens before the tables.>

> **Framing.** <The one structural truth that makes this journey distinctive — the
> thing that makes it break where it breaks. In a principal designer's voice.>

---

## 1. Stage-by-stage audit

### Stage 1 — <name>

**User goal:** <what they're trying to accomplish here.>

| | Current state (friction) | Future state |
|---|---|---|
| Reality | <what actually happens today> | <the redesigned behavior> |
| **Desktop** | <current or —> | <desktop future state> |
| **Mobile** | <current or —> | <mobile future state> |
| <Agent/System> role | <None / today's role> | <what the system/agent should do> |
| Emotional arc | <state today> | <state after> |
| Risk | — | <the guardrail this stage must respect, with a metric where possible> |

> **Divergence note.** <When desktop and mobile should behave differently here,
> and which platform owns this stage. Only where it diverges.>

<...repeat for every stage...>

> **Moment of truth #N — <name>.** <Where trust is won or lost. What structurally
> beats the named competitor here, and what happens if this moment fails.>

---

## 2. Emotional journey (all platforms)

​```
Stage1     Stage2     Stage3     …      StageN
  ◦          ◦          ▲ relief         ▲ closure
<label>    <label>    <PEAK / MoT>      <label>
​```
<Two sentences: name the dips that have historically killed this journey and how
the redesign converts them into relief.>

---

## 3. Platform divergence summary

| Stage | Desktop posture | Mobile posture | Primary platform |
|---|---|---|---|
| <stage> | <posture> | <posture> | **<Desktop / Mobile / Both>** |

> **Design principle.** <The one-line rule for who owns what — e.g. desktop is the
> comparison/decision environment, mobile is the discovery/transaction/physical one.>

---

## 4. Cross-platform continuity requirements   <!-- if multi-channel -->

1. **Thread persistence.** <state that must survive a device switch.>
2. **No re-asking.** <answers never re-requested on the other device.>
3. **Notification routing.** <which channel gets which update.>

---

## 5. Audit findings — prioritized

| # | Finding | Severity | Stage |
|---|---|---|---|
| F1 | <finding> | Critical | <stage> |
| F2 | … | High | |
| F3 | … | Medium | |

> **The thesis of the audit:** <which 2–3 findings are make-or-break, and why fixing
> them repositions the product against its named competitor. Leverage, not summary.>

---

*Companion documents: <links>.*
*Version <n>*
```

---

### Notes on Template B

- **Every stage opens with User goal** — the audit is anchored in intent, not screens.
- **The row set is consistent across stages:** `Reality / Desktop / Mobile / [System-or-agent] role / Emotional arc / Risk`. Consistency is what lets a reader scan the whole journey.
- **Current vs. future in the same table** — the honesty of the genre is showing today's friction next to the fix, side by side, so nobody forgets what's broken.
- **Blockquotes carry the "why":** Framing at the top, Divergence notes where platforms split, Moments of truth at the pivotal stages, Thesis at the end. These are arguments, not recaps.
- **The emotional arc is an ASCII line** marking peaks and dips — usually the two moments that have always killed the journey, which the redesign is built to convert.
