# Severity / Priority Legend

The scoring vocabulary every audit shares, so "P0" and "High" mean the same thing across documents and teams.

## Priority dots

| Dot | Tier | Meaning |
|---|---|---|
| 🔴 | **P0 — Critical** | Breaks the core job or destroys trust. The journey fails without this fixed. |
| 🟠 | **P1 — High** | Major friction or a real competitive gap; not fatal, but costs conversion/retention. |
| 🟡 | **P2 — Medium** | Noticeable friction; worth fixing, not urgent. |
| 🟢 | **P3 — Future** | Strategic or aspirational; high value but heavy or long-horizon. |

Template B's findings table may use the plain **Critical / High / Medium** scale instead of dots — both are valid; pick one and use it consistently within a document.

## Effort × Impact

Score each recommendation on both, so the roadmap can sort by leverage.

- **Effort:** Low (a field default, a copy change, a config) · Medium (new component, moderate dev) · High (structural design + dev) · Very High (new platform capability, partnerships, ML).
- **Impact:** Medium · High · Very High — judged on the core job and named-competitor positioning, not on how satisfying the fix feels to ship.

The prize quadrant is **Low effort × High/Very-High impact** — those become quick wins.

## The roadmap lens (three tiers over the same table)

Don't make a separate list. Tag each prioritized finding with one lens tier so the team can filter by appetite:

- **Quick wins** — low effort, high impact. Often a required-field change, a smart default, or a microcopy fix. Ship this quarter.
- **Strategic overhauls** — structural design/dev. New selectors, new flows, new services.
- **Copy & clarity fixes** — microcopy, labels, empty states, error strings. Cheap, and they compound.

## ID conventions

- **Template A touchpoints:** `S1, S2…` for the first actor (seller), `B1, B2…` for the second (buyer). One stable ID per touchpoint, assigned once, never reused.
- **Template B stages:** reference by stage name; findings still get IDs.
- **Findings (both templates):** `F1, F2…`, ordered by severity. An ID is a promise: it stays attached to that finding across versions so a standup can say "did we close F3?" a quarter later.
