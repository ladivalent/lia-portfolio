Lia DiValentin's design skills for Claude
https://liadivalentin.vercel.app/Process.dc.html#skills

Each folder is one Claude skill. To add one in Claude, zip the folder (or use the single-skill
zips on the site) and upload it as a skill. Guide:
https://support.claude.com/en/articles/12512180-use-skills-in-claude

They are written for my workflow. Swap in your own standards, design system and tools.
Free to use and adapt.
