---
name: "prototype-prompt-generator"
description: Use when the user wants an end-to-end clickable prototype prompt, a prototype-generation spec for Claude artifacts / Claude Design / v0 / Bolt / Lovable / Figma Make, or a platform-specific (desktop / mobile web / native) interactive prototype. Trigger whenever someone wants to turn a product concept or user flow into a pasteable spec that makes a code-gen tool build a genuinely clickable prototype — or wants the runnable prototype built directly in Claude. Also fires on "make me a prototype prompt," "spec out a clickable demo," "turn this flow into something I can click through," or "I need a prototype of X," even when no tool is named.
---

# Prototype Prompt Generator

## What this produces

A **Prototype Generation Prompt** is not the app and not raw code — it is the *pasteable spec* that makes a code-gen tool (Claude artifacts, v0, Bolt, Lovable, Figma Make) build a genuinely clickable prototype. Its value rests on three things: it is **self-contained** (assumes the downstream tool has read nothing else), **precise enough that the output feels like a real app** (wired interactions, real mock data, active loading states), and **honest about scope** — one happy path built fully beats ten half-built ones.

Read `references/emitted-prompt-template.md` before you start, then work the procedure.

## Step 1 — Gather inputs

Collect these. Where something's missing, make an explicit assumption and flag it inline rather than stalling:

- **Product concept + the one headline idea** the prototype must make visible. If everything is equally important, nothing lands — pin the single thing.
- **Target platform(s)** — Desktop / Mobile Web / Native (and the primary, if several). This drives the whole Platform & Format block; see `references/platform-paradigms.md`.
- **Core user flow(s)** plus **one concrete happy-path query in the user's own words** ("couch near me, ready this weekend"). The quoted query is what makes the happy path feel real instead of abstract.
- **Structural shape** — continuous journey vs. scenario picker (Step 3).
- **Brand / aesthetic direction** for the token system — kept brand-safe. If the user has their own design system (a design system artifact, a token file, a Figma library), name it; its tokens then replace the starter in `references/design-tokens.md`.
- **Tool target** — Claude artifact / Claude Design / v0 / Bolt / Lovable / React Native / Flutter. This matters most for Native (see the honest tech-target call below) and for Claude Design (see the note in Step 2).
- **Mode 1 or Mode 2** (Step 2).

## Step 2 — Pick the mode (default Mode 1)

- **Mode 1 (default) — emit the PROMPT.** Produce the tool-agnostic Prototype Generation Prompt document (Section A core block + optional B/C/D). Deliver it as Markdown the user copies into their tool of choice.
- **Mode 2 — build it here.** Actually generate the runnable interactive prototype now, as an artifact the user can click inside Claude. Before writing any component you **must load the design skill this session lists for the surface you are building on**: `artifact-design` for a published artifact page, `frontend-design` where that skill is the one available. If neither is listed, say so and carry on with the token system from Step 5. Write **all** interactive logic in full, use real mock-data arrays, and never truncate or leave `// rest here` comments. A Mode-2 deliverable that doesn't actually run is a failure.

**Claude Design as a target — say what it is.** Claude Design is now the Design artifact type inside Claude: artboards laid out on a canvas, built on a design system artifact when one is attached. Pick it when the goal is screens to look at and compare. Pick an HTML artifact when the goal is a flow to click through with real state. If the user asks for a "Claude Design prototype," say which of the two they will get and why, rather than quietly building one and calling it the other.

If the user hasn't said which mode, default to Mode 1 and mention Mode 2 exists.

## Step 3 — Pick the structural shape

The two shapes are the same genre; choose by what the prototype needs to prove. Both are laid out in `references/emitted-prompt-template.md`.

- **Shape 1 — Continuous Journey.** N numbered stages, all reachable as states, with **one happy path built fully end-to-end** from a concrete query. Use when the goal is to show a *complete flow* (Discover → … → Close).
- **Shape 2 — Scenario Picker.** A top tab picker over several discrete demo scenarios, each demonstrating one pattern, jumpable in any order. Use when the goal is to *showcase multiple distinct patterns/methods* rather than one continuous flow.

Genuinely ambiguous → present both with a one-line tradeoff and ask. Don't default to whichever you saw last.

## Step 4 — Branch the platform paradigm

This is the load-bearing step that mobile-first prompts usually skip. The Platform & Format block **must** branch to the requested target — full cheatsheet in `references/platform-paradigms.md`:

- **Desktop Web** — persistent multi-pane layouts, hover states, keyboard shortcuts, dense IA, side-by-side comparison surfaces.
- **Mobile Web** — fluid grid, thumb-zone ergonomics, ≥44×44px tap targets, a centered device frame (~390–420px), bottom sheets over modals.
- **Native (iOS / Android)** — native primitives: bottom tab bar, sheet/drawer modals, gesture interactions, idiomatic transitions.

**The honest native tech-target call — never fudge this.** A Claude artifact runs web (HTML, CSS and JavaScript, React included); it *cannot* run React Native or Flutter. So when the target is "native":
- If the output has to run as a Claude artifact → **emulate native primitives in web and say so explicitly** in the emitted prompt.
- If the target is an external tool that supports it → emit a **React Native or Flutter** prompt instead.
- Never imply a Claude artifact can run RN/Flutter. Stating the constraint out loud is part of the deliverable's honesty.

When multiple platforms are requested, name the primary and describe how the layout adapts across the others — don't pretend one layout fits all.

## Step 5 — Write Section A with full clickable logic

Section A is **one self-contained block the user can copy in a single motion.** It contains, in order: Role · Platform & Format · Core Concept/Story · The Journey (Shape 1) *or* The Scenarios (Shape 2) · The Happy Path · System/Agent Behavior · Graceful Degradation + State Variations · Interactions & Polish · Design Tokens · Deliverable. The exact skeleton is in `references/emitted-prompt-template.md`.

Two things make the difference between a clickable prototype and a wall of dead buttons:

- **Wire every interaction in cause→effect form.** Not "add a cart button" but: *"On tap of 'Add to cart' → increment `cartCount` → slide in the cart drawer → set the button to 'Added' → revert after 2s."* Spell out the chain.
- **Name the state variables the tool should hold** — `selection`, `thread`, `filters`, `activeToggle`, `cartCount`. Naming them gives the prototype real memory instead of hardcoded screens.

Also required inside Section A:
- **Active execution states** — sequential status microcopy ("Checking availability… Confirming pickup window… Done") with skeleton loaders, so agent/system work feels alive rather than frozen.
- **Reversibility as visible receipts** — where an agent applies something automatically, show it as an editable, undoable facet (the steering wheel), plus a "Why am I seeing this?" trail. Automated ≠ opaque.
- **Graceful degradation + ≥3 toggleable UI states** (empty / loading / success / error) with **visible in-sandbox toggles**, so a reviewer can see every state without reproducing the conditions.
- **A concrete count of mock records** (e.g. "8 listings") so comparison and edge states are actually demonstrable.
- **A design-token system** — explicit palette + type scale + spacing/rounding scale. Consistency over decoration, brand-safe, never a real brand's exact values. Starter in `references/design-tokens.md`; an attached design system artifact's tokens take its place.

Two lines the template file does not yet carry. Add both to every emitted Section A:

- **An `AVOID` line at the end of DESIGN TOKENS.** Current Claude models fall back on a few default looks when direction is thin, and a general instruction such as "avoid a generic AI look" only swaps one default for another. Name the specific patterns to keep out. Seed list, to be cut down to what this brand direction does not want: cream or off-white page backgrounds, italic accent words in headlines, numbered "01 / 02 / 03" section labels, monospace labels, pill-shaped buttons. Drop any item the brand actually calls for, and add any default you saw in an earlier build.
- **A `DONE WHEN` line at the end of DELIVERABLE.** Name the finish line so the tool does not stop at a good-looking first screen: every stage or tab is reachable by clicking, the happy path completes from the quoted query, every state toggle changes what is on screen, and nothing is a dead end.

## Step 6 — Add B / C / D and the presentation layer

- **Section B — optional deep-dive modules** (`B1, B2…`): appendable blocks for other paths, a deeper single moment, a desktop comparison environment, a multimodal-entry flow.
- **Section C — if the tool asks clarifying questions**: pre-answer tech stack, data, brand, scope priority, "the one thing that must land," and tone of copy, so the builder doesn't stall.
- **Section D — using this in Claude + presentation layer**: build as a single artifact, iterate stage-by-stage; plus the optional Design-Rationale-drawer / speaker-notes layer that turns the prototype into a presentation tool, and a few iterative refinement prompts. Always include this one among them: *"List the visual styles you used that I did not ask for, then rebuild without them."* Its answer is what extends the `AVOID` line.

## The brand-safety note (always)

Every emitted prompt opens with a brand-safety instruction: build an **original, `<brand>`-inspired** prototype with placeholder copy and generic imagery; never reproduce a real brand's exact logo, proprietary fonts, or copyrighted content. Portfolio-safe by default. This is non-negotiable and appears in every Mode-1 output; in Mode 2, apply the same rule to what you build.

## Step 7 — Self-check before delivering

One critique pass:

- **Is Section A genuinely self-contained?** Could someone paste only that block, having read nothing else, and get a real app? If it references outside context, fold that context in.
- **Is every interaction wired to real named state?** No dead buttons; no screen that can't be reached.
- **Does Section A carry both an `AVOID` line and a `DONE WHEN` line**, each specific to this prototype rather than copied from the seed list?
- **Mode 2 only:** does the code actually run, with all logic written out and real mock arrays — no truncation, no Lorem Ipsum, no placeholder comments? Check it against its own `DONE WHEN` line: where the session has a browser, open the build and click the happy path through to the end. If it could not be run, say so in the delivery instead of calling it verified.
- **Native honesty:** if native was requested, did you make the explicit emulate-in-web vs. RN/Flutter call rather than fudging it?
- **Claude Design honesty:** if Claude Design was the target, did you say whether the result is artboards or a clickable flow?
- **Brand-safe:** original styling, placeholder assets, no real logos/fonts/listings.
- **Scope honesty:** one happy path built fully, not ten stubs.
- **Voice:** agent/UI copy is warm, concise, competent — a knowledgeable associate, not a legal disclaimer.

Tighten, then deliver.

## Reference files

- `references/emitted-prompt-template.md` — the full Mode-1 document skeleton, with both Shape-1 and Shape-2 variants of the diverging block. Add the `AVOID` and `DONE WHEN` lines from Step 5 to it when emitting.
- `references/platform-paradigms.md` — desktop / mobile-web / native cheatsheet + the honest native tech-target call.
- `references/design-tokens.md` — a brand-safe token starter (palette, type scale, spacing/rounding).
- In **Mode 2**, also load the session's design skill (`artifact-design`, or `frontend-design` where that is the one listed) before writing any component.
