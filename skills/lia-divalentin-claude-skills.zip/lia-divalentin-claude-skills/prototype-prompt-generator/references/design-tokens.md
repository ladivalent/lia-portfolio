# Design Token Starter

A brand-safe starting token system to drop into the DESIGN TOKENS line of Section A. The point is a *consistent system*, not decoration — and never a real brand's exact values. Swap the hues/scales to match the requested aesthetic; keep the structure.

## Palette (semantic, not brand-literal)

```
--color-primary:      <hue>      /* main action / brand accent — pick an original hue */
--color-primary-ink:  <hue-dark> /* text/icon on primary surfaces */
--color-surface:      #FFFFFF    /* cards, sheets */
--color-bg:           #F6F7F9    /* app background */
--color-text:         #16181D    /* primary text */
--color-text-muted:   #5B6270    /* secondary text */
--color-border:       #E4E7EC    /* dividers, input borders */
--color-success:      #1A7F5A
--color-warning:      #B26A00
--color-error:        #C0362C
--color-info:         #2563A8
```

Rule: one primary hue, a neutral ramp (bg → surface → border → muted → text), and four semantic colors. Resist adding more — restraint reads as intentional.

## Type scale

```
--font-sans: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;  /* system fonts = brand-safe */
--text-xs:   12px / 500
--text-sm:   14px / 500
--text-base: 16px / 400
--text-lg:   18px / 600
--text-xl:   22px / 600
--text-2xl:  28px / 700
--text-3xl:  34px / 700
```

Use **system fonts** by default — never a real brand's proprietary typeface. If a distinctive feel is needed, an open-licensed font (Inter, Source Sans) is safe.

## Spacing + rounding

```
--space: 4 · 8 · 12 · 16 · 24 · 32 · 48   /* 4px base scale */
--radius-sm: 8px    --radius-md: 12px    --radius-lg: 16px    --radius-full: 999px
--shadow-sm: 0 1px 2px rgba(16,24,40,.06)
--shadow-md: 0 4px 12px rgba(16,24,40,.10)
```

## Why a token system beats ad-hoc styling

Tokens are what make a prototype read as a *product* rather than a mockup: every card shares the same radius, every action the same primary, every gap a step on one scale. When you tell the code-gen tool "use these tokens everywhere," you get consistency for free and the reviewer's eye stops catching seams.
