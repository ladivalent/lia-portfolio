# Emitted Prompt Template (Mode 1)

The skeleton of the document the skill emits. Fill each `<...>`. Keep the parts and their order. Section A must remain **one self-contained block** the user can copy in a single motion — everything the downstream tool needs lives inside it.

---

```
# <Product> — Prototype Generation Prompt
## <Platform(s)> · <Shape: Continuous Journey | Scenario Picker>

| Field | Value |
|---|---|
| Document | <Product> — Prototype Generation Prompt |
| Use with | Claude artifacts · v0 · Bolt · Lovable · Figma Make |
| Version | <n> |

**How to use.** Paste Section A into your code-gen tool as a single block. Append any
Section-B modules you want. Section C pre-answers the tool's clarifying questions; Section D
covers running it in Claude + the presentation layer.

> **Brand-safety note.** Build an ORIGINAL, <brand>-inspired prototype: placeholder copy,
> generic imagery, an original token system. Do NOT reproduce any real brand's exact logo,
> proprietary fonts, or copyrighted content. Portfolio-safe by default.

---

## SECTION A — THE CORE PROMPT  (copy this whole block)

​```
ROLE
You are a principal designer + front-end engineer. Build a high-fidelity, genuinely
clickable prototype. Favor depth over breadth: one path built fully beats ten stubs.

PLATFORM & FORMAT
Self-contained, no backend, all mock data in-memory. WCAG AA. <PLATFORM BRANCH — paste the
matching block from platform-paradigms.md: Desktop Web / Mobile Web / Native, incl. the
honest emulate-in-web-vs-RN/Flutter call for Native.>

THE CORE CONCEPT / STORY
<The single headline idea this prototype must make visible, in one or two sentences.>

<<< SHAPE 1 — CONTINUOUS JOURNEY >>>
THE JOURNEY
<N numbered stages; every stage is a reachable state.>
  1. <Stage> — <what's on screen, what the user can do>
  2. <Stage> — …
  …
THE HAPPY PATH
Drive the whole flow from this concrete query, quoted verbatim: "<user's own words>".
Build THIS path fully, end to end. Make stages <X> and <Y> the richest.

<<< SHAPE 2 — SCENARIO PICKER >>>
THE SCENARIOS
A top tab picker over these discrete demos, jumpable in any order; each demonstrates ONE
pattern fully:
  • Tab 1 — <scenario / pattern>
  • Tab 2 — <scenario / pattern>
  …
Each tab is self-contained and independently clickable. No required order.
<<< end shape fork >>>

SYSTEM / AGENT BEHAVIOR
- Active execution states: sequential status microcopy ("<step 1>… <step 2>… Done") with
  skeleton loaders, so work feels alive.
- Reversibility: every automated step leaves an undoable "receipt" — an editable facet the
  user can override. Include a "Why am I seeing this?" trail on agent decisions.
- <Any adaptation that changes visible behavior for a repeat/known user.>

GRACEFUL DEGRADATION + STATE VARIATIONS
- At least one empty / relaxed path (no results → widen criteria).
- ≥3 toggleable UI states (empty / loading / success / error) with VISIBLE in-sandbox
  toggles, so a reviewer can see every state without reproducing conditions.

INTERACTIONS & POLISH
- Real navigation between ALL states; nothing is a dead end.
- Wire interactions cause→effect, e.g.: "On tap of <X> → set <state> → <UI effect> →
  revert after <n>s." Name the state the tool holds: <selection, thread, filters, toggles…>.
- Transitions / streaming where it adds life. Include <N> mock records so comparison and
  edge states are demonstrable. Real, plausible mock data — never Lorem Ipsum.

DESIGN TOKENS
Palette: <primary / surface / text / accent / semantic>. Type scale: <sizes/weights>.
Spacing + rounding scale: <e.g. 4/8/12/16/24 · radius 8/12/16>. Consistency over decoration.

DELIVERABLE
A single runnable prototype. Start at <stage/tab>. Make <the money moment> the richest and
most polished screen.
​```

---

## SECTION B — OPTIONAL DEEP-DIVE MODULES   (append as needed)

**B1 — <other path / deeper moment>**: <paste-on block that extends Section A.>
**B2 — <desktop comparison environment / multimodal entry / …>**: <block.>

## SECTION C — IF THE TOOL ASKS CLARIFYING QUESTIONS

- Tech stack: <e.g. React + Tailwind, single file.>
- Data: <mock, in-memory, N records.>
- Brand: <original, brand-safe token system.>
- Scope priority: <the one path/screen to build richest.>
- The one thing that must land: <the headline moment.>
- Tone of copy: <warm, concise, competent — a knowledgeable associate.>

## SECTION D — USING THIS IN CLAUDE + PRESENTATION LAYER

- Build as a single artifact; iterate stage-by-stage rather than all at once.
- Optional presentation layer: a Design-Rationale drawer / speaker-notes overlay that turns
  the prototype into a walkthrough tool.
- Iterative refinement prompts: "<make stage X richer>", "<add the error state for Y>",
  "<tighten the token system>".

---

*Companion documents: <links>.*
*Version <n>*
```

---

### Notes

- **The shape fork touches only two blocks** — THE JOURNEY vs. THE SCENARIOS (and the happy-path framing). Everything else in Section A is invariant. Pick one fork, delete the other and the `<<< >>>` markers before emitting.
- **Section A is sacred as a single block.** If a reader would have to scroll up into Section 0 or over to Section B to understand something, fold it into A. Self-containment is the whole value.
- **The DELIVERABLE line names the money moment** — the one screen worth over-investing in. Every strong prototype prompt tells the tool where to spend its polish budget.
