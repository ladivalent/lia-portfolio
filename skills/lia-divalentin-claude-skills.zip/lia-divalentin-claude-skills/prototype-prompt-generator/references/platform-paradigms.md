# Platform Paradigms Cheatsheet

The Platform & Format block of Section A must branch to the requested target. Paste the matching block into the emitted prompt. This is the load-bearing step that mobile-first prompts usually skip — a prototype that ignores platform paradigm feels wrong no matter how polished.

---

## Desktop Web

```
PLATFORM: Desktop web (≥1280px). Persistent multi-pane layout — e.g. left nav / center
content / right detail or agent panel. Hover states on interactive elements. Keyboard
shortcuts for power actions. Dense, scannable information architecture. Side-by-side
comparison surfaces (the desktop advantage — show trade-offs at a glance). Modals and
side-drawers rather than full-screen takeovers.
```

Desktop is the **comparison and decision** environment: more screen, side-by-side trade-offs, denser data.

## Mobile Web

```
PLATFORM: Mobile web. Center the app in a device frame ~390–420px wide on the page. Fluid
single-column grid. Thumb-zone ergonomics — primary actions reachable at the bottom. Tap
targets ≥44×44px. Bottom sheets instead of modals. Sticky bottom CTA. Full-screen threads
over side panels.
```

Mobile web is the **discovery and transaction** environment: location, wallet, quick capture.

## Native (iOS / Android)

```
PLATFORM: Native <iOS | Android>. Native primitives — bottom tab bar, sheet/drawer modals,
gesture interactions (swipe, long-press), platform-idiomatic transitions and system fonts.
<TECH-TARGET LINE — see the honest call below.>
```

### The honest native tech-target call — never fudge this

A Claude artifact runs **web (React)**. It cannot run React Native or Flutter. So "native" resolves one of two ways, and the emitted prompt must **say which out loud**:

- **Target = Claude artifact** → *emulate* native primitives in web (React) and state it plainly:
  > "This runs as a web prototype emulating <iOS/Android> native patterns (bottom tab bar, sheet modals, gesture affordances). It approximates native feel; it is not a native build."
- **Target = external tool that supports it (Expo, RN sandbox, FlutterFlow, etc.)** → emit a **React Native or Flutter** prompt instead of a web one, and name the runtime.

Never imply a Claude artifact can run RN/Flutter. The honesty *is* part of the deliverable — a stakeholder who thinks they're seeing a native build when they're seeing emulated web will make wrong decisions.

## Multiple platforms requested

Name the **primary** platform and build for it fully; then describe how the layout **adapts** to the others (what collapses, what moves, what changes interaction model) rather than pretending one layout serves all three. A "start comparing on desktop, finish the purchase on mobile" hand-off is the model: each platform owns the stages it's best at.
