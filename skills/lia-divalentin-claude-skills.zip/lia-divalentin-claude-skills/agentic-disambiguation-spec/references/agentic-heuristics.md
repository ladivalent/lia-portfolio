# The 13 Heuristics of Agentic UX

> These 13 are this skill's working set, drawn from well-grounded agentic-UX principles. If your team has its own heuristics, swap them in here — keep the `H#` numbering stable — and the skill will cite yours instead.

The skill cites these by number, e.g. `[H4: Reversibility]`. Each requirement, component mechanic, and loop must trace to at least one.

| # | Heuristic | What it demands |
|---|-----------|-----------------|
| **H1** | **Agent legibility** | The agent's presence, role, and current activity are always visible. The user is never unsure whether the agent is acting, waiting, or done. (Visibility of agent status.) |
| **H2** | **Clarify intent before acting** | When intent is ambiguous or confidence is low, ask rather than guess. Disambiguation precedes irreversible commitment. |
| **H3** | **Design for uncertainty** | Express confidence honestly as calibrated scores; degrade gracefully when unsure instead of projecting false certainty. |
| **H4** | **Reversibility (always undo)** | Every automated action leaves a reversible receipt. Nothing the agent does is a one-way door without explicit consent. |
| **H5** | **Feedback loops drive behavior** | Capture explicit and implicit signals, and visibly show the system responding to them. |
| **H6** | **Adjustable autonomy** | The human can dial the agent's independence up or down at any moment — from suggest-only to act-with-confirmation to act-autonomously. |
| **H7** | **Responsible memory** | Persist preferences transparently. Memory is viewable, editable, and resettable by the user; the agent says when it has learned something. |
| **H8** | **Surface the agent's field of view** | Expose what the agent can see — the data, context, and sources behind a decision — so its reasoning is inspectable. |
| **H9** | **Human control of consequential decisions** | Irreversible, destructive, or high-stakes actions require explicit human consent. Steering beats speed here. |
| **H10** | **Preview before committing (Last Safe Moment)** | Simulate / dry-run the intended action and show its cost, time, data touched, and destructive implications before execution. |
| **H11** | **Explain on demand** | The agent can justify any decision ("Why am I seeing this?") without cluttering the default view. |
| **H12** | **Preserve context & continuity** | Never reset the thread or hide results behind a takeover. State persists across turns, methods, and devices. |
| **H13** | **Model and expose tradeoffs** | When options compete, show the tradeoff (cost vs. speed, breadth vs. precision) rather than hiding it behind one silent answer. |

## Compact legend (for the spec's Overview section)

`H1` Legibility · `H2` Clarify-first · `H3` Uncertainty · `H4` Undo · `H5` Feedback · `H6` Adjustable autonomy · `H7` Memory · `H8` Field of view · `H9` Human control · `H10` Preview/Last-Safe-Moment · `H11` Explain-on-demand · `H12` Continuity · `H13` Tradeoffs
