# Component Catalog Skeleton

The per-method entry template. Copy it once per disambiguation method the use-case needs. Keep the sub-parts and their order; keep the IDs stable.

---

```
### Method <n> — <method name>   (e.g. Inline Chips · Adaptive Slider · Confirmation Prompt)

**Selection signature.** Fires when: confidence <band> × stakes <low/med/high> ×
profile <thin/rich> (+ reversibility <reversible/irreversible>).
> e.g. "0.55–0.80 confidence · low stakes · any profile · reversible → inline chips."

**PRD requirements**
| ID | Requirement (MUST / SHOULD, with numeric threshold) | Heuristics |
|----|------------------------------------------------------|------------|
| R1 | The system MUST <behavior + threshold>. | [H2][H3] |
| R2 | The component SHOULD <behavior>. | [H6] |
| R3 | The system MUST pause and drop to explicit consent if confidence < <x> OR the action is irreversible. | [H9][H10] |

**Net-new component(s)**

**C<n> — <Component name>**
- *Intent:* <the one job this component does that a stock control can't.>
- *Visual / spatial affordances:* <layout; how it reveals the agent's field of view [H8];
  how it exposes autonomy choices [H6]; where it sits relative to results.>
- *Interactive mechanics:* <how the user overrides, pivots, changes autonomy mode, or
  refines a parameter — in cause→effect terms.>

**Data states**
| State | What renders |
|-------|--------------|
| Empty | <before the agent has anything> |
| Thinking | <agent is extracting/deciding — skeleton + status microcopy> |
| Resolving | <options presented; user acting> |
| Committing | <selection applied; receipt + undo shown> |

**Microcopy**
- Prompt: "<warm, concise, competent — a knowledgeable associate>"
- Confirm: "<…>"
- Learned: "<Got it — I'll <remembered preference> next time.>"

**Thread-state rule.** <How this method stays non-blocking: inline / bottom-sheet / side-panel;
never a full takeover; never resets the thread or hides results.> [H12]

**Heuristics cited:** [H#][H#][H#]
```

---

### Guidance per common method

- **Inline chips** — low-friction, non-blocking refinements shown beside live results. Signature: mid confidence, low stakes. Watch over-prompting (cap the number of chips).
- **Adaptive slider with live count** — a continuous parameter (radius, price, date-range) with the result count updating live as the user drags. Reveals consequence before commit. [H10][H13]
- **Confirmation prompt** — the explicit-consent gate. Reserved for higher stakes or lower confidence; never used for trivial reversible actions (that's over-prompting). [H9]
- **Multiple-choice cards** — when the ambiguity is a small discrete set (which "Bill"?). Cards over a dropdown because they carry the agent's field-of-view evidence per option. [H8]
- **Silent contextual inference + undo** — high confidence + low stakes: act, but leave a visible, editable receipt. The undo is what makes silence safe. [H4]
- **Visual style tiles** — for aesthetic/style ambiguity ("modern? rustic?"), show tiles, not words.
- **Repair mid-flow** — let the user correct a wrong inference without restarting; the thread and prior answers survive. [H12]
- **Graceful fallback** — when no method resolves it, degrade to the simplest explicit choice rather than guessing or erroring. [H3]
