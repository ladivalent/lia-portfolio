# The Four Data States

Every agentic component ships all four states, specified — not just the happy "resolved" view. A component missing its Thinking or Committing state feels broken the moment the agent is slow or the network stalls, which is exactly when trust is most fragile.

| State | When it shows | What must render | Heuristic |
|-------|---------------|------------------|-----------|
| **Empty** | Before the agent has anything to show, or before the user has engaged. | A purposeful zero-state — what the component is for and how to start. Not a blank box. | [H1] |
| **Thinking** | The agent is extracting signals or deciding. | Skeleton loaders + **sequential status microcopy** ("Reading your query… Checking options…"). The work must feel alive, never frozen. | [H1][H3] |
| **Resolving** | Options / the disambiguation surface are presented and the user is acting. | The choices, each carrying the agent's field-of-view evidence; the override/refine affordances; autonomy controls. | [H6][H8] |
| **Committing** | A choice has been applied and the action is being taken. | Confirmation of what's happening, plus the **receipt + undo** — and, for anything irreversible, this is where the preview / Last-Safe-Moment gate lives. | [H4][H9][H10] |

## Why all four, always

- The **Empty** state is the component's first impression; a blank box reads as broken.
- The **Thinking** state is where perceived competence is won or lost — silent spinners feel dead; sequential microcopy feels like a capable associate at work.
- The **Resolving** state is the actual disambiguation; it must expose *why* these options (field of view), not just the options.
- The **Committing** state is where safety lives — the receipt, the undo, and (for irreversible actions) the preview gate. Skipping it is how agents quietly do irreversible things.

When you write a catalog entry, fill the four-row table concretely for that specific component. "Loading spinner" is not a Thinking-state spec; "skeleton cards + 'Checking availability at 4 nearby sellers…'" is.
