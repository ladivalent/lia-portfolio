---
name: agentic-disambiguation-spec
description: Use when the user wants agentic-search UX requirements, net-new disambiguation components, an agentic UX component spec, transaction-boundary / undo / "last safe moment" patterns, or feedback and memory-loop design for an AI agent. Trigger whenever someone needs to spec HOW an agent handles messy or ambiguous human intent — semantic collisions, scope vagueness, parameter ambiguity, destructive-action risk — with purpose-built components governed by named heuristics, not generic dropdowns, modals, or error boxes. Also fires for agent steering, adjustable-autonomy controls, or memory view/edit/reset UX.
---

# Agentic Disambiguation & Feedback Spec

## What this produces

This deliverable is the design↔engineering contract for **how an agent handles messy human intent, and how it learns.** It is **method-indexed**: for each disambiguation method the agent can use, it specifies when that method fires, the net-new component that carries it, the requirements that govern it, and the feedback it produces.

Its whole premise is that traditional UI — dropdowns, error boxes, generic modals — *fails* in agentic workflows. An agent that silently guesses and shows an error box when it's wrong is worse than no agent. So every component here is purpose-built for human-agent collaboration, and every choice is auditable to a **heuristic** and a **metric**.

Read `references/component-catalog-skeleton.md` for the per-method entry template, and `references/data-states.md` for the four-state checklist. Then work the procedure.

## The governing framework — cite a heuristic for everything

The rigor of this genre is that **every requirement, component mechanic, and loop cites the specific heuristic(s) it serves**, e.g. `[H4: Reversibility]`. Load them from `references/agentic-heuristics.md`, the skill's working set of 13. If the user's team has its own heuristics, they can swap them into that file (keeping the `H#` numbering) and the skill cites those instead.

Never ship an uncited requirement, and never silently invent a heuristic number. A citation you're unsure of gets flagged, not hidden.

## Step 1 — Gather inputs

Collect these; flag gaps as `[ASSUMPTION TO VALIDATE]` rather than inventing:

- **The agentic use-case** and the **specific ambiguity type(s)**: semantic collision (search "Bill" = person vs. invoice), scope vagueness ("clean up my files"), parameter ambiguity ("high cost" — how high?), destructive-action risk (delete, pay, send).
- **The stakes / reversibility profile** of the actions involved — money, safety, data loss, and whether each action is reversible.
- **Confidence thresholds** the product uses, or propose calibrated defaults (and mark them to validate). These must agree with the Intent-to-Model Mapping if one exists.
- **The team's own heuristics**, if they use a set other than the bundled 13 (see above).
- **Feedback signals** the product can capture (explicit ratings, implicit overrides/dwell) and **where memory persists**.

## Step 2 — Identify the disambiguation methods the use-case needs

Don't spec every method reflexively — spec the ones this use-case actually calls for. The common catalog:

inline chips · adaptive slider with live result count · confirmation prompt · multiple-choice cards · silent contextual inference + undo · visual style tiles · repair mid-flow · graceful fallback.

Add any the use-case demands; drop any it doesn't. A destructive-action-heavy product leans on confirmation + preview; an exploratory-search product leans on chips + sliders + inference.

## Step 3 — Write each catalog entry

For every method, produce a full entry using the template in `references/component-catalog-skeleton.md`. Each entry has, in order:

- **Selection signature** — the `confidence × stakes × profile (+ reversibility)` condition that triggers this method. This is the bridge to the routing model (next section). State it explicitly so the spec and the Intent-to-Model Mapping agree instead of drifting.
- **PRD requirements** — explicit MUST/SHOULD statements with **numeric thresholds**, each citing its heuristic(s). Example: *"R3 — The system MUST pause execution and drop to explicit consent if intent confidence < 0.75 OR the action is irreversible. [H2][H9]"*. Give requirements stable IDs (`R1, R2…`).
- **Net-new component(s)** — 1–2 per method, each with: **Name & Intent**; **Visual / Spatial Affordances** (how it reveals the agent's field of view [H8] and its adjustable-autonomy choices [H6]); **Interactive Mechanics** (how the user overrides, pivots, changes autonomy mode, or refines parameters). Give components stable IDs (`C1, C2…`).
- **Data states** — Empty / Thinking / Resolving / Committing, each specifying what renders. See `references/data-states.md`.
- **Microcopy** — concrete example strings, warm and competent, never a legal disclaimer.
- **Thread-state rule** — the method never resets the thread or hides results behind a full takeover. [H12]
- **Heuristics cited** — the roll-up for the entry.

### The selection-logic bridge (state it for every method)

Which method fires is a function of **confidence × stakes × profile (+ reversibility)** — the same signal the Intent-to-Model Mapping routes on:

- **Low confidence** → **Ask** (chips, cards, confirmation). [H2][H3]
- **High confidence + low stakes** → **silent inference with undo**. [H4]
- **Irreversible / destructive** → **forced drop to explicit consent + preview**, regardless of confidence. [H9][H10]
- **Rich profile** → prefer inference and skip prompts the profile already answers. [H7]

Spelling out each method's signature is what keeps this document and the routing model in agreement.

## Step 4 — Transaction boundaries + feedback loops

**Interactive preview & transaction boundaries — the "Last Safe Moment."** Specify the dry-run / simulation / diff of what the agent *intends* to execute: cost, time, data touched, and destructive implications. Specify the explicit undo/rollback pattern and a prominent freeze/abort control (with a countdown if the action auto-commits). Cite `[H4][H10][H13]`. Destructive or irreversible actions **always** get preview + explicit consent + undo — no exceptions.

**Feedback & evolution loops.** Specify how the interface captures explicit and implicit signals, how it *communicates that the system learned* from this specific interaction (not a silent model update — a visible "Got it, I'll default to pickup near you next time"), and the controls to **view, edit, or reset** the agent's persistent memory of the preference. Cite `[H5][H7]`.

## Step 5 — Auditability matrix

Close with a table mapping **each component → the heuristic(s) it serves → the eval metric that proves it works.** This mirrors the eval table that closes an Intent-to-Model Mapping: every behavior traces to a number. Use metrics like over-prompting rate, override rate, wasted-destruction rate, memory-reset usage, disambiguation-abandon rate. A mis-firing component then maps to a metric that moved, not a vibe.

## Step 6 — Self-check before delivering

- **Every requirement and every mechanic cites a heuristic.** Scan for uncited claims — they're the most common failure.
- **Every component is net-new**, not a repackaged dropdown or a generic error modal. If a component could be swapped for a stock control without loss, it isn't agentic — redesign it.
- **Every component ships structural layout + the four data states + real microcopy.** A component missing its Thinking or Committing state is incomplete.
- **Destructive/irreversible → preview + explicit consent + undo, always.** No exceptions, cite `[H9][H10][H4]`.
- **Confidence is calibrated scores + a stakes/reversibility class**, never a bare "high/low."
- **Stable IDs** on every component (`C#`) and requirement (`R#`).
- **Could an engineer build directly from this?** If a mechanic is described in adjectives instead of behavior, make it concrete. No corporate filler.

Tighten, then deliver.

## Output format

A single Markdown document with the invariant structure: header metadata table → overview + heuristics legend → the method→component catalog → transaction boundaries → feedback loops → auditability matrix → footer. Use design-rationale blockquotes for the "why" after the catalog and the matrix, in a principal designer's voice.
