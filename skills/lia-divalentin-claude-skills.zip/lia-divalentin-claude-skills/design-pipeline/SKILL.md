---
name: "design-pipeline"
description: "Run lia's design skills end to end on one problem: brief, AI spec, prototype prompt, critique, delivered as a single packet. Use for 'run the pipeline', 'take this from problem to prototype', 'full design packet'."
---

# Design Pipeline

This skill is the conductor, not a player. It runs lia's existing design skills in order on one problem and makes sure each stage builds on the last instead of starting cold. Each stage keeps its own rules and self-check. This skill adds three things they can't do alone: one intake instead of five, a ledger that carries decisions and open questions forward, and a final check that the prototype actually serves the problem the brief defined.

The failure this exists to prevent: a prototype that looks great but quietly solves a different problem than the brief, or an AI spec whose thresholds disagree with the routing model.

## The stages

| # | Stage | Skill to load (Skill tool) | Runs when |
|---|-------|---------------------------|-----------|
| 1 | Problem brief | `design-problem-brief` | Always |
| 2 | Intent-to-model mapping | `intent-model-mapping` | The product has an AI agent, assistant, or AI search/routing |
| 3 | Disambiguation spec | `agentic-disambiguation-spec` | Stage 2 ran and the agent faces ambiguity or takes consequential actions |
| 4 | Prototype prompt | `prototype-prompt-generator` | Always |
| 5 | Critique + trace check | `design:design-critique` | Always |

Skill names may carry an `anthropic-skills:` prefix in the listing; use whichever form is listed. If a skill isn't available, do that stage's work directly following the contract below and say so in the cover memo.

For a non-AI product, skip stages 2 and 3 and say in the cover memo that they were skipped and why. Never pad them out.

## Step 1 — One intake for everything

The downstream skills each want inputs. Collect them all in one batched round up front so lia answers once, then runs straight through. Pull everything you can from what she already gave you first, and ask only for what's missing and load-bearing:

- **Raw material** for the brief: research quotes, analytics, eng/PM notes (stage 1).
- **Response-move spine** — the set of moves the agent chooses among. Propose a candidate spine from the material and get a yes. This is the one confirmation stage 2 forbids skipping (stage 2).
- **Stakes and reversibility** of the actions the agent takes (stages 2–3).
- **Platform and tool target** for the prototype, plus Mode 1 (prompt) or Mode 2 (build it here). Default Mode 1 (stage 4).
- **The one headline idea** the prototype must make visible (stage 4).

Use AskUserQuestion when available, at most four questions. If lia isn't there to answer (a scheduled run, or she said to just go), take the most reasonable reading, record every guess in the ledger as an assumption, and proceed.

After intake, don't stop between stages. Each skill normally ends by offering next moves; inside the pipeline, suppress those offers and carry on. The only mid-run stop is a contradiction that would make later stages wrong (see Step 3).

## Step 2 — Keep a ledger

Create `pipeline-ledger.md` in the working folder before stage 1 and update it after every stage. It holds:

- **Assumptions** — every `[CRITICAL ASSUMPTION TO VALIDATE]` and `[ASSUMPTION TO VALIDATE]` flag raised by any stage, with its stage and the question that resolves it.
- **Tensions** — contradictions the brief preserved, and any new ones later stages hit.
- **Decisions** — the confirmed response-move spine, confidence thresholds, platform, mode, shape.
- **IDs** — archetypes (stage 1), intent classes (stage 2), requirements `R#` and components `C#` (stage 3).

The ledger is how context survives from stage to stage. Before starting each stage, reread it.

## Step 3 — Run the stages with handoffs

Run each stage by loading its skill and following it in full, including its self-check. What makes this a pipeline is the handoffs:

**1 → Problem brief.** Runs as normal. Its outputs set the frame for everything after: the problem statement, the two archetypes, the success outcomes, the constraints, and out-of-scope.

**1 → 2. Intent mapping.** The brief's archetypes become the adaptation and repeat-user worked examples. The brief's constraints feed the stakes model. Out-of-scope items get no intent class. Representative queries come from the brief's research quotes where they exist, rather than invented ones.

**2 → 3. Disambiguation spec.** Every selection signature uses the exact thresholds and stakes classes from the stage 2 confidence table. If stage 3 needs a threshold stage 2 didn't define, add it to stage 2's table and note the change in the ledger. The two documents must agree. Every intent class stage 2 routes to disambiguation gets a method in stage 3.

**1 + 3 → 4. Prototype prompt.** The happy path is written from the brief's primary archetype, in their words. The headline idea must address the brief's problem statement. Graceful degradation reflects the brief's constraints (mobile, rushed, poor signal, and so on). If stage 3 ran, pick Shape 2 (scenario picker) when the point is to show several disambiguation components, with each scenario labeled by its `C#`; pick Shape 1 when the point is one continuous flow, and wire the relevant components into it. Nothing out of scope appears in the prototype.

**Stop condition.** If a later stage finds that an earlier one is wrong (for example, the prototype can't serve the brief's success outcome within its constraints), stop, name the conflict in one or two sentences, and ask lia which way to go. If she's not available, fix the earlier document, note it in the ledger, and continue.

## Step 4 — Critique and trace check

Load `design:design-critique` and critique the stage 4 output: the prototype prompt as a spec (Mode 1), or the built prototype (Mode 2). Then run the trace check, which is this pipeline's own contribution:

- **Outcome trace.** For each success outcome in the brief, name where in the prototype it becomes observable. An outcome with nowhere to show up is a gap.
- **Archetype trace.** Does the happy path serve the primary archetype's motivation and stay under their proficiency threshold?
- **Spec trace** (if stages 2–3 ran). Every `C#` component appears in the prototype or is explicitly deferred. Irreversible actions get preview, explicit consent, and undo in the prototype, not only in the spec.
- **Scope trace.** Nothing out of scope crept in.

Fix what you can in the stage 4 document directly. List what you can't fix as open issues.

## Step 5 — Deliver one packet

Deliver everything together, once, at the end:

1. **Cover memo** (`00-cover-memo.md`), one page: the problem statement in one sentence, which stages ran and which were skipped and why, the trace check results, and the consolidated list of open assumptions from the ledger, ordered by how much they'd change the design if wrong. This is the page lia reads first.
2. **Stage documents**, numbered in run order: `01-problem-brief.md`, `02-intent-model-mapping.md`, `03-disambiguation-spec.md`, `04-prototype-prompt.md` (or the Mode 2 artifact), `05-critique.md`.
3. **The ledger**, `pipeline-ledger.md`.

Send the files, then in chat give three lines at most: the problem in one sentence, the single biggest open assumption, and the one next move worth making. Don't recap the stages; the cover memo does that.

## Self-check before delivering

- Intake happened once, and the response-move spine was confirmed or recorded as an assumption, never silently borrowed.
- Every stage that ran passed its own skill's self-check.
- Stages 2 and 3 agree on every threshold and stakes class.
- The prototype's happy path comes from the brief's archetype and addresses its problem statement.
- Every assumption flag from every stage is in the cover memo.
- Skipped stages are explained, not silently missing.