---
name: portfolio-presentation
description: Turn a project brief + prototype link into a storytelling portfolio presentation for design interviews (outline first, then a .pptx deck). Use this skill whenever the user wants to prepare, add, or update a portfolio case study for an interview, portfolio review, or design screen — including phrases like "portfolio presentation," "case study deck," "interview presentation," "present my project," "portfolio review," or when they link a project brief and/or prototype (Figma, live product, video) and want a presentation built from it. Also use when the user pastes interview requirements from a company and wants their work packaged to meet them. The output demonstrates senior/staff/principal IC craft depth AND director-level strategic thinking.
---

# Portfolio Presentation Builder

Turn raw project material (a brief, a prototype link, interview requirements) into a polished, narrative-style portfolio presentation that reads at senior/lead IC and director levels. Two deliverables, in order: **(1) a reviewable outline** with slide-by-slide content, timing, speaker notes and Q&A prep, then after user approval **(2) a .pptx deck** built from the approved outline.

The core belief driving this skill: interviewers don't hire process, they hire *judgment*. Every artifact this skill produces should surface specific decisions, the options that were killed and why, and the numbers that prove it mattered — not a tour of deliverables.

## Workflow

### Step 1 — Gather and read the inputs

Collect whatever the user provides; ask only for what's missing and essential:

1. **Project brief** — a file, doc link, or pasted text describing the project. Read it fully.
2. **Prototype link** — Figma, live product URL, Loom/video, or a deployed prototype. Fetch and analyze it (see Step 2).
3. **Interview requirements** (optional) — a company's prompt or rubric. If provided, treat it as the grading key: every requirement must map to a named slide before the outline is done.
4. **Requested slides** (optional) — the user may name specific slides or content they want in the case study ("include a slide on the design system I built," "I want my eval framework shown," "add the stakeholder map"). Collect these as must-haves; see Step 5 for how to place them.
5. **Format** — decide between the two supported formats (see Step 3). If ambiguous, ask.

If the user gives only a brief with no prototype, proceed — mark prototype demo slots as placeholders and tell the user which slides need them.

### Step 2 — Analyze the prototype

Interviewers explicitly reward live product and functional prototypes, so the prototype is evidence, not decoration. Extract from it:

- The **end-to-end flow** (name the screens/states in order)
- The **hardest interaction** — the one worth a deep-dive slide (micro-transitions, edge states, ambiguity handling)
- 2–3 **specific design decisions** visible in the artifact (a default chosen, an interaction pattern, a recovery path)

How to fetch, by link type: Figma links → Figma MCP tools (`get_metadata`, `get_screenshot`, `get_design_context`) if connected, otherwise ask the user for key screens. Live URLs → web_fetch; if the page is client-rendered, use Claude-in-Chrome navigation + page text. Video links → ask the user for 3–4 timestamps worth calling out. If nothing is fetchable, ask the user to describe the 2–3 screens they're proudest of.

Reference concrete, observed details from the prototype in the outline ("the size-disambiguation sheet on the PDP", not "the final design"). Specificity is the craft signal.

### Step 3 — Pick the narrative format

Read `references/single-project-format.md` or `references/multi-story-format.md` — only the one that applies:

- **Single project deep-dive** (`references/single-project-format.md`) — one project, usually AI-focused, ~30–45 min. Use when the requirements ask for "one project" or the user supplies one brief.
- **Multi-story cohesive narrative** (`references/multi-story-format.md`) — two or more case studies with a connecting through-line. Use when requirements ask for multiple projects or the user supplies 2+ briefs. Two stories is the sweet spot for a 30-min slot; the reference explains how timing and depth scale (and when to advise the user to cut a story rather than shallow all of them).

Both formats share one spine per story: *people problem → why it was hard → explorations & killed options → final design end-to-end + one deep-dive → testing & collaboration → impact vs. success criteria → reflection*. The format references tune timing and emphasis, not the spine.

### Step 4 — Extract the story from the brief

Before writing any slide, pull these out of the brief (and prototype) into working notes. If any is missing, ask the user — these can't be invented:

- **People problem** in one plain sentence: "People trying to ___ can't ___ because ___", plus the audience and how the problem was validated (data, research, tickets).
- **Business + technical context**: why it mattered *now*, the constraint that shaped the design (model latency, ranking systems, legal, legacy platform).
- **Success criteria committed up front** — the metrics the results slide will be judged against.
- **The role split**: what the user owned vs. directed vs. influenced, and who else was on the team.
- **2–3 real explorations** with the reason each losing option was killed (a data point or a principle — "we killed B because ___").
- **Role of AI** — both in the product and in the user's process (tools like Cursor/Claude Code used to prototype, synthesize, or eval). Interviewers increasingly ask for this explicitly.
- **Impact numbers** and how they were measured.
- **One honest reflection** — a real thing they'd do differently, not a humblebrag.

While extracting, read `references/seniority-signals.md` and tag where each senior-IC and director-level signal will land in the deck. If a signal has no home, that's a gap to fix in the outline — not something to fake.

### Step 5 — Write the outline (deliverable 1)

Produce a single `.md` file using the structure in `assets/outline-template.md`. It must include:

1. **Header block** — candidate, target level, format, interview structure.
2. **Timing table** — minutes and slide ranges per segment. Context per story capped at ~2 minutes; the majority of time goes to explorations, decisions, and craft.
3. **Slide-by-slide outline** — for every slide: title, the content that goes on it, the *speaker note* (what to say, first person, conversational), and a timing marker. Mark prototype-video and hi-fi-mock slots explicitly, referencing the actual screens found in Step 2.
4. **Requirements coverage map** — a table mapping each interview requirement (or the five standard focus areas) to the slide(s) that answer it. Any requirement with no slide is a bug.
5. **Anticipated Q&A** — 6–10 likely questions with crisp two-to-three-sentence answers, weighted toward the project's weak spots (the thing that didn't ship perfectly, the metric that's soft, the decision a skeptic would poke).
6. **Pitfall check** — confirm none of the outline commits the classic fouls: process-wall slides, >2 min of context, small screenshots, unconnected stories, generic "the team decided" passive voice.

**Placing requested slides.** Any slide the user asked for is a must-have, but *where* it lands is a design decision: weave it into the spine at the point where it strengthens the story (a design-system slide belongs in the explorations or collaboration beat; an eval-framework slide next to the testing beat), rather than bolting it on at the end. In the outline, tag it `(requested)` in the "why this slide exists" line so the user can see it landed. If a requested slide genuinely fights the narrative or the rubric's "avoid" list (e.g., a process-wall artifact), still include it — it's their call — but flag the tension and suggest the alternative in one line. If timing can't absorb it, say which slide you'd trade.

Before saving, **audit the timing arithmetic**: add up the per-slide/per-segment minutes and make them equal the allotted presentation time exactly (a table that says "30 min" but sums to 33 will be noticed by exactly the kind of interviewer this deck is for). If the segment table and the per-slide markers disagree, fix whichever is wrong — don't leave both.

Save it to the outputs folder and **stop for user review**. Present the outline and ask what to adjust before building the deck.

### Step 6 — Build the deck (deliverable 2, after approval)

Once the user approves the outline, read the pptx skill (SKILL.md in the pptx skill directory) and build the deck from the approved outline:

- One slide per outline entry; speaker notes go into the PowerPoint notes field.
- **Full-bleed image placeholders** for hi-fi mocks and prototype videos, labeled with exactly which asset the user should drop in ("Drop in: prototype video — size selector sheet, 30–45s"). Never fake mocks with drawn shapes pretending to be UI.
- Restrained, consistent visual system: one typeface family, generous whitespace, a 1–2 color accent, big type. The deck's own craft is being graded.
- If the prototype yielded real screenshots (e.g., via Figma MCP), place them full-bleed on the relevant slides.

Save the .pptx next to the outline and present both files.

## Judgment calls

- **Don't pad.** If the brief is thin, a short honest outline with named gaps beats an invented full one. List the gaps as "you need to supply: ___".
- **Numbers over adjectives.** Replace "significantly improved" with the actual number or a `[metric needed]` marker.
- **First person, active voice** in speaker notes. "I killed the carousel direction because scroll-depth data showed…" — never "it was decided."
- **The reflection must cost something.** A reflection that reveals no real tradeoff reads as evasive at senior levels.
