# [Interview / Company] — Portfolio Presentation Outline

**Candidate:** [name] · **Target level:** [Senior/Staff/Principal IC] · **Format:** [single project deep-dive | two-story narrative]
**Project(s):** [name — one-line description, shipped status, platforms]
**Prototype:** [link + what it demonstrates]
**Interview structure:** [e.g., 5 min intro · 30 min presentation · 10 min Q&A — questions held to end?]
**Through-line / thesis:** [the one sentence about how you design that every slide serves]

---

## Timing at a glance

| Segment | Time | Slides |
|---|---|---|
| [segment] | [min] | [n–n] |

> Context is capped at ~2 min per story. The majority of time goes to explorations, decisions, and craft.

---

## Slide-by-slide

<!-- Repeat this block per slide. Every slide gets all four fields. -->

### Slide [N] — [Title] ([time])

**On the slide:** [exact content: headline, the mock/video slot, the data point. Mark asset slots like: 🎬 PROTOTYPE VIDEO — {which interaction, target length} or 🖼 FULL-BLEED MOCK — {which screen}]

**Speaker note:** [first person, conversational, what you actually say — including the decision language: "I chose… because… it cost us…"]

**Why this slide exists:** [which requirement / focus area / seniority signal it serves — one line]

---

## Requirements coverage map

| Requirement (from the interview prompt) | Slide(s) |
|---|---|
| [each requirement, verbatim or near] | [n] |

<!-- Any requirement without a slide number is a gap — fix before finishing. -->

## Assets you need to supply

- [ ] [e.g., prototype video: size-selector sheet, 30–45s, screen-recorded at 2x]
- [ ] [e.g., hi-fi mock: final PDP, full-bleed export @2x]
- [ ] [e.g., metric: the actual conversion lift number for slide 13]

## Anticipated Q&A

<!-- 6–10 questions, weighted toward weak spots. Answers 2–3 sentences, first person. -->

**Q: [likely question]**
A: [crisp answer]

## Pitfall check

- [ ] No process-wall slides (post-its, personas, dense flowcharts)
- [ ] Context ≤ 2 min per story before first design decision
- [ ] No small screenshots — every mock full-bleed
- [ ] Prototype video (or hi-fi stand-in) for the hardest interaction(s)
- [ ] Active first-person voice at every decision point
- [ ] Impact ties back to the success criteria stated up front
- [ ] Reflection costs something real
