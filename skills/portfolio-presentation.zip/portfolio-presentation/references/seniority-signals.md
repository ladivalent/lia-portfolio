# Seniority Signals: Senior/Lead IC Craft + Director-Level Thinking

A portfolio presentation is graded on two axes at once. Senior/staff/principal IC evaluation asks *"is the craft and judgment deep?"*; director-level evaluation asks *"does this person think beyond their own screens?"*. A strong deck answers both without labeling them. Use this file while extracting the story (Step 4) to tag where each signal lands — and to spot gaps.

## Senior / Lead IC signals (craft depth)

| Signal | What it sounds like on a slide | What it sounds like when faked |
|---|---|---|
| Specific decisions | "I chose a bottom sheet over inline expansion because reachability data on 6.7" devices showed…" | "We iterated to the final design" |
| Range explored | 2–3 real directions as mocks, each with the reason it died | A single 'final' shown as inevitable |
| Interaction depth | A deep-dive on one hard interaction: edge states, error recovery, motion intent | A flow diagram standing in for interaction design |
| Craft in the artifact | Full-bleed hi-fi mocks; prototype video; the deck's own typography | Small screenshots, lorem-ipsum mocks |
| Evidence habits | "Testing changed X to Y — here's the before/after" | "Users loved it" |
| Honest reflection | A regret that cost something real, and what changed in their practice | "I'd have added more user research" |

## Director-level signals (strategic altitude)

| Signal | What it sounds like on a slide | What it sounds like when faked |
|---|---|---|
| Business framing | "This mattered *now* because [market/competitive/economic reason]" | Feature framing with no why-now |
| Problem selection | Evidence they found (or reframed) the right problem, not just solved the given one | Executing the brief as handed down |
| Tradeoff economics | "We shipped B over A: 80% of the value, one quarter earlier, no new infra" | Only user-experience justifications |
| Org influence | "My exploration artifact became the alignment doc for three teams" | "I collaborated cross-functionally" |
| Roadmap impact | "This work changed what the team built next" | Impact ends at the shipped feature |
| Team multiplication | Mentoring, decision frameworks, design systems others adopted | A list of meetings attended |
| Owned vs. directed vs. influenced | Explicit, honest role split — comfortable crediting others | Vague 'led the design' for everything |

## How to weave director signals into an IC deck

Director thinking shouldn't get its own section — it lives inside the IC story at specific points:

- **The context slide** carries the business framing (why now, in market terms).
- **The "what made this hard" slide** carries scale and organizational ambiguity, not just design difficulty.
- **The exploration slides** carry tradeoff economics — at least one option should be killed for a business or feasibility reason, not just a usability one.
- **The collaboration slide** carries org influence — the moment the candidate's artifact or argument moved people who didn't report to them.
- **The results slide** carries roadmap impact — what happened *after* shipping.
- **The reflection** carries growth trajectory — the practice change, which is the "growing continuously" evidence.

## Red flags that cap perceived level

These read as mid-level regardless of the work's actual quality — check the outline against them:

1. Passive voice at decision points ("it was decided", "the team chose").
2. Process theater — double-diamond diagrams, persona walls, post-it photos presented as evidence of rigor.
3. Context exceeding ~2 minutes before the first design decision appears.
4. Every option explored shown as equally good — no visible kill criteria.
5. Impact with no denominator ("increased engagement") or no tie to the success criteria stated at the start.
6. A reflection that is secretly a strength ("I care too much about craft").
7. Claiming sole credit in a way that leaves teammates invisible — senior people are precise and generous about attribution.
