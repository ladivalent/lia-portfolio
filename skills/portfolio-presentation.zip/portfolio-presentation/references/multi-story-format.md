# Multi-Story Cohesive Narrative Format

Two or more case studies woven into a single connected narrative — not separate decks stapled together. Typical container: 45 min screen = 5 min intro · 30 min presentation · 10 min Q&A (interviewer often holds questions to the end — confirm).

## How many stories?

The spine each story needs (~10 slides, ~10–12 min told properly) is what limits the count, not ambition:

- **2 stories** — the sweet spot for 30 min. Full spine for both.
- **3 stories** — only viable in 30 min as *one anchor + two supporting*: the anchor gets the full spine (~12 min), the supporting stories get a compressed spine (~6–7 min each: problem → one key decision with its killed option → final design → result → one-line reflection). Or a 45–60 min slot fits two full + one compressed.
- **4+ stories** — in a standard screen this becomes a portfolio scroll-through, the exact thing rubrics warn against. Advise the user to cut to the best 2–3; depth on fewer stories reads more senior than coverage of many. If they insist (e.g., a "career retrospective" format was explicitly requested), give every story the compressed spine and one shared deep-dive.

Whatever the count, tell the user which stories you'd anchor vs. compress and why — that ranking is itself a judgment the user can correct.

## The through-line comes first

Before outlining a single slide, pick the connective thread every story will reinforce — a consistent point of view about how the candidate designs. Examples: "designing for ambiguity at scale," "people-first decisions backed by data," "raising the craft bar on complex systems." State it in the opening, echo it once per story, land it in the close. The more stories, the more the through-line matters: it's what keeps N projects from reading as a list. If a slide doesn't serve the through-line or a rubric item, cut it.

## Deliberate contrast

Choose and order stories so the *set* shows range. Each story should showcase a different strength mix: interaction/motion craft vs. strategy/ambiguity, different platforms, or different leadership modes (0→1 solo vs. cross-team alignment vs. directing other designers). Say the contrast out loud in each transition slide — don't make the interviewer infer it. Avoid symmetric stories that prove the same strength twice; with 3+ stories, redundancy is the first thing to cut.

## Timing skeleton (30 min, 2 full stories — adjust per the counts above)

| Segment | Time | Slides (approx) |
|---|---|---|
| Title + who I am | 2 min | 1–2 |
| How I work (operating principles) | 1 min | 3 |
| **Case Study 1** | 12–13 min | 4–14 |
| Transition (the contrast, in one breath) | 30 sec | — |
| **Case Study 2** | 11–12 min | 15–24 |
| Growth, AI practice, close | 2 min | 25–26 |

For 3 stories in 30 min: anchor 12 min, supporting 6–7 min each, transitions 30 sec each — and trim the opening to 2 min. Re-derive the table for the actual count and slot; make it sum exactly.

## Per-story spine (~10 slides for full, collapse for compressed)

1. **Cover** — product, one-liner, shipped badge, platforms.
2. **Role & team** (30s) — owned vs. directed vs. influenced; duration; partners.
3. **People problem + business problem** (1 min) — one plain sentence each; audience; success criteria committed up front.
4. **What made this hard** (30s) — the staff-level frame: ambiguity, scale, constraints, competing stakeholders. Crisp, not a process wall.
5–6. **Explorations & options** (3 min) — 2–3 real directions as side-by-side mocks; why the killed ones died; one explicit road-not-taken with the data or principle that decided it.
7–8. **The design, end to end** (3 min) — full-bleed hi-fi mocks; compact end-to-end flow; then a deep-dive on the hardest interaction with a prototype video slot.
9. **Testing & collaboration** (2 min) — your role in research; a concrete before/after that testing forced; one moment a partner shifted the design and one where you shifted the roadmap.
10. **Results + reflection** (2 min) — shipped numbers vs. the slide-3 success criteria; what you'd change; one thing the project permanently changed about how you design.

**Compressed spine** (for supporting stories): cover + role in one slide → people/business problem → the one decision that defines the story, with its killed alternative → final design full-bleed → results + one-line reflection. Five slides, ~6–7 min. The deep-dive and testing detail live only in the anchor story.

Tune each story's emphasis to its contrast role — e.g., a story's "role & team" slide highlights a *different* leadership mode than the previous story's.

## Standard focus areas (when no rubric is provided)

Map coverage against these five and include the map in the outline. With multiple stories, each area needs a home in at least one story — not every area in every story:

1. Interaction & experience design — the prototype/deep-dive slides
2. Visual design & craft — full-bleed mocks + the deck's own typography
3. Growing continuously — reflections + closing AI-practice slide
4. Product thinking — problem framing, explorations, tradeoffs
5. Driving results & impact — role clarity + shipped numbers

## Format-specific pitfalls

- Stories with no shared visual language — the deck itself must look like one system.
- A through-line stated once at the start and never mentioned again.
- Later stories rushed because earlier ones ran long — the timing markers exist to prevent exactly this; hard-cap every story, especially the anchor.
- Symmetric stories that show the same strength twice.
- Adding a story because it exists rather than because it adds range — with N stories, every one must earn its minutes against the through-line.
