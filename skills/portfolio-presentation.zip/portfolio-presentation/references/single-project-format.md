# Single Project Deep-Dive Format

One project, presented deep. Common ask: "present one AI project (ideally launched) that shows you can solve complex, ambiguous problems with minimal support." Typical container: 45–60 min interview → budget ~30–35 min of presenting, leaving room for interruptions or held questions (confirm which mode with the user).

## Why this format is different from the two-story format

With one project there is nowhere to hide — depth *is* the differentiator. The risk profile inverts: in a two-story deck the danger is shallowness; here the danger is drowning in chronology. The fix is to structure the middle as **three or four named decisions**, not a timeline. Each decision gets: the fork in the road, the options, the evidence, the call, and what it cost.

## Timing skeleton (~30 min of content)

| Segment | Time | Notes |
|---|---|---|
| Who I am + how I work | 2–3 min | One slide of operating principles previews level |
| Project cover + role + team | 1–2 min | Owned vs. directed vs. influenced — say it explicitly |
| People problem + validation | 2 min | Problem statement + the data/insights that proved it real |
| Business + technical context | 2 min | Why now, and the constraint that shaped everything |
| What made this hard | 1 min | Ambiguity, scale, model behavior, stakeholders — crisply |
| **Decision walk (the core)** | **12–14 min** | 3–4 named decisions, explorations, killed options, deep-dive |
| Prototype / live demo | 3–4 min | The end-to-end flow, then the hardest interaction up close |
| Testing + collaboration | 2–3 min | What testing changed; one moment eng/PM shifted the design, one moment you shifted the roadmap |
| Role of AI | 1–2 min | AI in the product AND AI in your process (Cursor, Claude Code, synthesis, evals) |
| Impact | 2 min | Results vs. the success criteria stated earlier |
| Reflection | 1–2 min | What you'd do differently — must cost something |

## The decision walk

This is where the interview is won. For each of the 3–4 decisions:

1. **Name it** like a chapter ("Decision 2: disambiguate intent before the model guesses").
2. **Show the fork** — 2–3 real directions as mocks side by side, never described in prose alone.
3. **Show the evidence** — the data point, research insight, or principle that decided it.
4. **Say the call in first person** — "I killed B because…"
5. **Admit the cost** — what the winning option gave up. Tradeoffs stated voluntarily read as seniority; tradeoffs extracted under questioning read as defensiveness.

Pick decisions that show *different muscles*: one interaction-craft decision, one product-strategy decision, one AI-specific decision (prompt/model behavior, confidence thresholds, failure states, human-in-the-loop).

## AI-project specifics

AI projects have design problems ordinary projects don't. Interviewers for AI roles listen for these — cover the ones that apply:

- **Designing for non-determinism**: how the design handles the model being wrong (fallbacks, confidence thresholds, graceful degradation).
- **Ambiguity in user intent**: how vague input gets disambiguated before the system acts.
- **Trust calibration**: what the design does to avoid over- or under-trust in AI output.
- **Eval-informed design**: whether design decisions were tested against model behavior, not just user behavior.
- **Latency and cost as design materials**: where the design absorbed model latency or trimmed token cost.

## The "minimal support" signal

When the prompt says "with minimal support," the interviewer is probing autonomy. Weave in — without bragging — moments where there was no playbook: the ambiguous kickoff, the decision made without a PM, the artifact created that aligned the team because nothing else existed. The team-environment slide should make the role split unmistakable in one glance.
