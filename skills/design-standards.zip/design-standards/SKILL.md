---
name: "design-standards"
description: "Lia's baseline design standards, applied while building, editing or reviewing any design, prototype or spec. Also learns new rules from her hand edits when she says learn from my edits."
---

# Design standards

Lia should never have to say a basic rule twice. Apply these while building, check them before showing anything, and grow this file from her edits.

## How she briefs

- Metaphors in her briefs are prompts to explore, not names. Never put a working metaphor (song, verse, chorus, beats) into the product, its labels or its specs. Ship plain product terms: tasks, steps, checkout card, receipt.
- Treat the work as a real product for real shoppers, not a concept piece.

## Apply while building (every board, every time)

Frame and layout
- All content stays inside the artboard. Roots and components use box-sizing: border-box, so declared width includes padding and border. Nothing extends past the frame's width. If content is taller than the frame, grow the frame; never clip text.
- Imported components count: check them at their max width inside every board that imports them.
- Repeated cards in a row or list share one fixed height. CTAs pin to the bottom edge (margin-top: auto) and align across cards. Titles and detail lines truncate with an ellipsis, status clamps to two lines, the price row stays on one line.
- Spacing and type come from the attached design system. For pixel-level spacing and alignment, run design-polish-pass.
- Step-list markers never look like radio buttons; use numbers. Touch targets are at least 44px.

Shopper copy
- Standard shopping words: Total or Order total (never "all in"), Est. delivery, Budget (never "ceiling"), sold range or recent sales (never "band" or "comps"), Est. earnings for sellers, Cancel order for buyers, End listing for sellers, Buy It Now, Make offer, Counteroffer, Watchers, Active.
- One meaning per word on a screen. If a word is both a gesture and a state ("hold"), rename the state.
- Never two names for one list, and never a section named the same as its page.
- Buttons name the outcome ("Press and hold to pay $179.09", "View order"). Status chips use shopper states (Offer sent, Order placed, Active). The agent asks for "approval", not "OK".
- No em dashes, en dashes or double hyphens in UI copy. No combative words.
- No contradictions: a guarantee beside a limit that denies it, or a promise the flow breaks.

Checkout (US and New York, not legal advice)
- Before the charge: the item (title, size, condition); the total with shipping and tax shown before the button; the return policy near the item or before billing details (NY GBL 218-a); the amount and payment method charged.
- Elsewhere: high-volume seller details on the listing or order confirmation (INFORM Act); one consent to the agent's terms, with the terms link beside the opt-in button.
- Optional but true if shown: est. delivery (reasonable basis), cancel window (honor it), protection badges, agent limits, agent steps.
- Checkout order: Ship to, Est. delivery, Pay with, Order summary, Buyer protection and returns, what the agent couldn't check, agent steps, button. A price shows once in the summary and once on the button. The seller and rating sit beside the item.

Consistency
- Desktop and iOS twins carry the same copy and structure.
- Specs and plan boards match the screens they document; callouts point at the right rows.
- Sample data agrees everywhere: tax rate for one ZIP, counts, account numbers, dates.
- Canvas notes that quote UI copy change with it.

## Check before showing

1. Re-read the current version if her edit count changed. Never edit from an old copy.
2. For every changed board, and every board that imports a changed component: root width plus padding and border against the frame, and content height against the frame.
3. Search visible copy for working names and banned words.
4. Fix clear defects. Bring real design decisions as one recommendation with its tradeoff.
5. Say what was not verified (for example, the rendered screens were not viewed).

## Learn from her edits

When she says "learn from my edits", or after she has polished boards by hand:
1. Keep a local copy of every version you read or publish. Read the current files and compare them with that copy.
2. For each change, write the rule behind it in one line ("gap between price and status 12 to 16: price block needs more air"). Skip one-off content changes.
3. Show her the rules as a short list. She confirms, corrects or drops each one.
4. Add confirmed rules to the matching section and the log, then propose this file updated so she can save it.

When she states a rule in passing ("keep the text on the artboard"), add it the same way. She should not have to ask twice.

## Rule log

- 2026-10-22: Content stays on the artboard, padding inside the width (checkout and spec boards overflowed).
- 2026-10-22: Fixed-height cards with bottom-aligned CTAs.
- 2026-10-22: Shopper words only; working metaphors never reach the UI.
- 2026-10-22: Checkout legal minimum, return policy on every checkout.