---
name: "commerce-design-review"
description: "Review shopping and agentic-commerce designs against Lia's standards: shopper copy, card layout, checkout legal minimum, consistency across screens. Use for review this, check the copy, QA the checkout."
---

# Commerce design review

Lia's review standards for e-commerce and agentic shopping designs (Claude Design canvases, HTML, Figma, screenshots). Every rule here came from a correction she made. Run the checks, fix what is clearly a defect, and bring her only the calls that are hers to make.

## How to run

1. Read the current version first. If the canvas shows a higher edits count than your last read, read it again. Never edit from an old copy.
2. Pull every visible string and every root and container style. Include the iOS twins and any spec or plan boards that document the screens.
3. Run sections 1 to 4 in order. For each finding note: where, what is wrong, the fix.
4. Apply clear defects. Bring design decisions (an interaction change, removing a section, renaming a product or mode) as one recommendation with its tradeoff.
5. For spacing and pixel alignment, run design-polish-pass after this review.
6. Report what you checked, what you changed, and what you could not verify (for example, that you did not view the rendered screens).

## 1. Shopper copy

- Use standard shopping words: Total or Order total (never "all in"), Est. delivery, Budget (never "ceiling"), sold range or recent sales (never "band" or "comps"), Est. earnings for sellers, Cancel order for buyers, End listing for sellers, Buy It Now, Make offer, Counteroffer, Watchers, Active.
- One meaning per word on a screen. If a word is both a gesture and a state (for example "hold"), rename the state.
- No internal framework words in the UI: verses, chorus, beats, the names of your team's agent-role framework, Memory. Use shopper labels: Request / Results / Checkout, Preferences, Checkout.
- Never two names for one list, and never a section named the same as its page (a "For you" section on the For You page).
- Buttons name the outcome: "Press and hold to pay $179.09", "View order", "Review offer".
- Status chips state the state in shopper terms: Offer sent, Order placed, Active.
- The agent asks for "approval", not "OK".
- No em dashes, en dashes or double hyphens in UI copy. No combative words.
- No contradictions: a guarantee next to a limit that denies it (Authenticity Guarantee beside "I can't check authenticity"), or a promise the flow breaks ("never bids without approval" beside "set a max bid").

## 2. Cards and layout

- Cards in a row or list have a fixed height. CTAs are pinned to the bottom edge (margin-top: auto) so they align across cards. Title and detail lines truncate with an ellipsis, status clamps to two lines, the price row stays on one line.
- Roots and component containers use box-sizing: border-box so padding sits inside the declared width. Nothing is wider than its artboard: check declared width plus padding plus border against the frame. Check the components a board imports too.
- A price appears once in the summary and once on the button, not more.
- The seller name and rating sit next to the item, not only in an activity log.
- Step-list markers never look like radio buttons (no empty circles). Use numbers.
- Checkout order: Ship to, Est. delivery, Pay with, Order summary, Buyer protection and returns, what the agent couldn't check, agent steps, then the button.

## 3. Checkout legal minimum (US and New York, not legal advice)

Must appear before the charge:
- The item: title, size, condition.
- The total, with shipping and tax shown before the button.
- The return policy, near the item or before billing details (NY GBL 218-a, since August 2025; otherwise the seller owes a 30-day refund).
- The amount and the payment method being charged.

Required somewhere else:
- High-volume seller name, address and contact on the listing or the order confirmation (INFORM Consumers Act).
- One clear consent to the AI agent's terms, with the terms link beside the opt-in button.

Optional, but true if shown: est. delivery (needs a reasonable basis under the FTC Mail Order Rule), the cancel window (must be honored), protection badges, agent limits, agent steps.

Flag every checkout variant that is missing a return policy. Say it is not legal advice and that the client's legal team has the final word.

## 4. Consistency

- Desktop and iOS twins carry the same copy.
- Specs and plan boards match the screens they document. Flag stale specs and callouts that point at rows that moved.
- Sample data agrees across screens: tax rate for the same ZIP, counts ("4 of 8"), account numbers, dates.
- Canvas notes that quote UI copy change with it.

## 5. Output

Findings first, grouped by section: location, issue, fix, and whether it was applied or needs Lia's call. Then one recommendation for anything that is her decision. End with what was not verified. Keep it short and plain.

## Training log

When Lia corrects something this skill missed, add the rule to the matching section and a dated line here, then propose the updated skill so she can save it.

- 2026-10-22: Labels like "Your verses in progress" mixed internal song terms with unclear status words.
- 2026-10-22: Active tasks cards need a fixed height and aligned CTAs.
- 2026-10-22: Checkout artboards and the card were wider than their frames (padding outside the width).
- 2026-10-22: Spec boards had the same overflow since the first version.
- 2026-10-22: Checked which checkout content is legally required; return policy missing on Cart and Collect.